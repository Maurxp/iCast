import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import * as http from 'http';
import { parseRange, createTestServer } from '../../scripts/test-server';

describe('test-server range parsing', () => {
  const size = 1000;

  it('returns null when no range is provided', () => {
    expect(parseRange('', size)).toBeNull();
  });

  it('parses explicit start and end', () => {
    expect(parseRange('bytes=0-499', size)).toEqual({ start: 0, end: 499 });
  });

  it('parses open-ended start', () => {
    expect(parseRange('bytes=500-', size)).toEqual({ start: 500, end: 999 });
  });

  it('parses suffix range', () => {
    expect(parseRange('bytes=-200', size)).toEqual({ start: 800, end: 999 });
  });

  it('returns invalid when start >= fileSize', () => {
    expect(parseRange('bytes=1000-', size)).toBe('invalid');
  });

  it('returns invalid when start > end', () => {
    expect(parseRange('bytes=500-400', size)).toBe('invalid');
  });

  it('returns invalid on non-numeric values', () => {
    expect(parseRange('bytes=abc-def', size)).toBe('invalid');
  });
});

describe('test-server HTTP requests', () => {
  let server: http.Server;
  let serverPort: number;

  beforeAll(async () => {
    server = createTestServer();
    await new Promise<void>((resolve) => {
      server.listen(0, '127.0.0.1', () => {
        const addr = server.address();
        if (addr && typeof addr === 'object') {
          serverPort = addr.port;
        }
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  });

  function request(
    options: http.RequestOptions,
  ): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: Buffer }> {
    return new Promise((resolve, reject) => {
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: serverPort,
          ...options,
        },
        (res) => {
          const chunks: Buffer[] = [];
          res.on('data', (c) => chunks.push(Buffer.from(c)));
          res.on('end', () => {
            resolve({
              statusCode: res.statusCode || 0,
              headers: res.headers,
              body: Buffer.concat(chunks),
            });
          });
        },
      );
      req.on('error', reject);
      req.end();
    });
  }

  it('serves synthetic_test.mp4 with 200 OK and correct headers', async () => {
    const res = await request({ path: '/synthetic_test.mp4', method: 'GET' });
    expect(res.statusCode).toBe(200);
    expect(res.headers['content-type']).toBe('video/mp4');
    expect(res.headers['accept-ranges']).toBe('bytes');
    expect(Number(res.headers['content-length'])).toBeGreaterThan(900000);
    expect(res.body.length).toBe(Number(res.headers['content-length']));
  });

  it('serves 206 Partial Content for byte range request', async () => {
    const res = await request({
      path: '/synthetic_test.mp4',
      method: 'GET',
      headers: { Range: 'bytes=0-99' },
    });
    expect(res.statusCode).toBe(206);
    expect(res.headers['content-type']).toBe('video/mp4');
    expect(res.headers['content-length']).toBe('100');
    expect(res.headers['content-range']).toMatch(/^bytes 0-99\/\d+$/);
    expect(res.body.length).toBe(100);
  });

  it('serves 206 Partial Content for suffix range request', async () => {
    const res = await request({
      path: '/synthetic_test.mp4',
      method: 'GET',
      headers: { Range: 'bytes=-50' },
    });
    expect(res.statusCode).toBe(206);
    expect(res.headers['content-length']).toBe('50');
    expect(res.body.length).toBe(50);
  });

  it('serves 416 Range Not Satisfiable for out of bounds range', async () => {
    const res = await request({
      path: '/synthetic_test.mp4',
      method: 'GET',
      headers: { Range: 'bytes=99999999-999999999' },
    });
    expect(res.statusCode).toBe(416);
    expect(res.headers['content-range']).toMatch(/^bytes \*\/\d+$/);
  });

  it('responds to HEAD requests with empty body and correct content length', async () => {
    const res = await request({ path: '/synthetic_test.mp4', method: 'HEAD' });
    expect(res.statusCode).toBe(200);
    expect(res.headers['content-type']).toBe('video/mp4');
    expect(Number(res.headers['content-length'])).toBeGreaterThan(900000);
    expect(res.body.length).toBe(0);
  });

  it('blocks path traversal attempts with 403 Forbidden', async () => {
    const res = await request({ path: '/%2e%2e/%2e%2e/package.json', method: 'GET' });
    expect(res.statusCode).toBe(403);
  });

  it('returns 404 for nonexistent files', async () => {
    const res = await request({ path: '/nonexistent.mp4', method: 'GET' });
    expect(res.statusCode).toBe(404);
  });
});
