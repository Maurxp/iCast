import { createServer, IncomingMessage, ServerResponse, Server } from 'http';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';

export interface TestServerOptions {
  port?: number;
  host?: string;
  fixturesDir?: string;
}

export const MIME_TYPES: Record<string, string> = {
  '.mp4': 'video/mp4',
  '.m4v': 'video/mp4',
  '.m3u': 'application/x-mpegurl',
  '.m3u8': 'application/vnd.apple.mpegurl',
  '.ts': 'video/mp2t',
  '.json': 'application/json',
  '.xml': 'application/xml',
};

export function getLanIp(): string {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    const list = interfaces[name];
    if (!list) continue;
    for (const iface of list) {
      if (iface.family === 'IPv4' && !iface.internal) {
        // Prefer standard 192.168.x.x LAN over VPN / virtual adapters
        if (iface.address.startsWith('192.168.')) {
          return iface.address;
        }
      }
    }
  }
  // Fallback to any non-internal IPv4
  for (const name of Object.keys(interfaces)) {
    const list = interfaces[name];
    if (!list) continue;
    for (const iface of list) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

export function parseRange(
  rangeHeader: string,
  fileSize: number,
): { start: number; end: number } | 'invalid' | null {
  if (!rangeHeader || !rangeHeader.startsWith('bytes=')) {
    return null;
  }
  const parts = rangeHeader.slice(6).split('-');
  if (parts.length !== 2) return 'invalid';

  const rawStart = parts[0].trim();
  const rawEnd = parts[1].trim();

  let start: number;
  let end: number;

  if (rawStart === '') {
    // Suffix range: -N means last N bytes
    const suffix = parseInt(rawEnd, 10);
    if (isNaN(suffix) || suffix <= 0) return 'invalid';
    start = Math.max(0, fileSize - suffix);
    end = fileSize - 1;
  } else {
    start = parseInt(rawStart, 10);
    if (isNaN(start) || start < 0) return 'invalid';
    if (rawEnd === '') {
      end = fileSize - 1;
    } else {
      end = parseInt(rawEnd, 10);
      if (isNaN(end) || end < start) return 'invalid';
    }
  }

  if (start >= fileSize) {
    return 'invalid';
  }
  end = Math.min(end, fileSize - 1);
  return { start, end };
}

export function createTestServer(options: TestServerOptions = {}): Server {
  const baseDir = path.resolve(options.fixturesDir || path.join(process.cwd(), 'scripts', 'fixtures'));

  return createServer((req: IncomingMessage, res: ServerResponse) => {
    // CORS headers for local testing
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { 'Content-Type': 'text/plain' });
      res.end('Method Not Allowed');
      return;
    }

    const rawReqUrl = req.url || '/';
    if (rawReqUrl.includes('..') || rawReqUrl.toLowerCase().includes('%2e%2e')) {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      res.end('Forbidden: Path Traversal Detected');
      return;
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawReqUrl, `http://${req.headers.host || 'localhost'}`);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Bad Request');
      return;
    }

    let rawPath = parsedUrl.pathname;
    try {
      rawPath = decodeURIComponent(rawPath);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Bad Request');
      return;
    }

    if (rawPath === '/' || rawPath === '') {
      rawPath = '/synthetic_test.mp4';
    }

    // Path traversal check
    const safePath = path.resolve(baseDir, '.' + rawPath);
    if (!safePath.startsWith(baseDir + path.sep) && safePath !== baseDir) {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      res.end('Forbidden: Path Traversal Detected');
      return;
    }

    fs.stat(safePath, (err, stats) => {
      if (err || !stats.isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');
        return;
      }

      const ext = path.extname(safePath).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      const fileSize = stats.size;

      const rangeHeader = req.headers.range;
      if (rangeHeader) {
        const range = parseRange(rangeHeader, fileSize);
        if (range === 'invalid') {
          res.writeHead(416, {
            'Content-Range': `bytes */${fileSize}`,
            'Content-Type': 'text/plain',
          });
          res.end('Requested Range Not Satisfiable');
          return;
        }

        if (range) {
          const chunkSize = range.end - range.start + 1;
          res.writeHead(206, {
            'Content-Range': `bytes ${range.start}-${range.end}/${fileSize}`,
            'Accept-Ranges': 'bytes',
            'Content-Length': chunkSize,
            'Content-Type': contentType,
          });

          if (req.method === 'HEAD') {
            res.end();
            return;
          }

          const stream = fs.createReadStream(safePath, { start: range.start, end: range.end });
          stream.on('error', () => {
            if (!res.headersSent) {
              res.writeHead(500);
            }
            res.end();
          });
          stream.pipe(res);
          return;
        }
      }

      // No range header: full file
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': contentType,
        'Accept-Ranges': 'bytes',
      });

      if (req.method === 'HEAD') {
        res.end();
        return;
      }

      const fullStream = fs.createReadStream(safePath);
      fullStream.on('error', () => {
        if (!res.headersSent) {
          res.writeHead(500);
        }
        res.end();
      });
      fullStream.pipe(res);
    });
  });
}

// Standalone execution
if (process.argv[1] && process.argv[1].endsWith('test-server.ts')) {
  const port = Number(process.env.TEST_SERVER_PORT) || 8088;
  const host = '0.0.0.0';
  const server = createTestServer();
  const lanIp = getLanIp();

  server.listen(port, host, () => {
    console.log(`[TestServer] Running on http://localhost:${port}`);
    console.log(`[TestServer] LAN stream: http://${lanIp}:${port}/synthetic_test.mp4`);
  });
}
