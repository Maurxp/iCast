# Procedimiento de Despliegue Físico Controlado
## Misión M2.2 — webOS IPTV Player (LG 65UM7400PDA)
**Fecha:** 30 de Octubre de 2026  
**Objetivo:** Procedimiento paso a paso para la futura instalación del paquete M2.2 en el televisor real  

> [!IMPORTANT]
> **POLÍTICA DE DESPLIEGUE:** Este procedimiento **NO debe ejecutarse de forma automática**. Requiere autorización expresa del usuario antes de enviar cualquier comando de instalación al televisor.

---

## 1. Identificación de Versiones y Verificación Previa

### 1.1 Versión Instalada Actualmente en el TV
- Archivo de origen: `AUDIT_REPORTS/MISSION_2/package/com.lennylxx.iptv_1.17.0_all.ipk`
- Tamaño: 733.772 bytes
- SHA-256: `253648B348F1E5B16E073B07786FBE07A1B68B44026ADFF453B163003CEE9CD5`
- Estado: Ejecución activa con HLS y DASH validados.

### 1.2 Versión Candidata para Instalación (M2.2)
- Archivo: `AUDIT_REPORTS/MISSION_2_2/package/com.lennylxx.iptv_1.17.0_all.ipk`
- Tamaño: 734.610 bytes
- SHA-256: `9B4B02B69C7E70A0EE1BEE15B4F27583872C6F5D3D5B33707CD339F4F53FA531`
- Novedades: Soporte MP4 nativo, clasificación HTTP temprana, `"inspectable": false`.

---

## 2. Procedimiento Oficial de Instalación Paso a Paso

### Paso 1: Comprobación de Conectividad con el TV
Verificar que la conexión SSH administrativa y la IP LAN del televisor sigan activas:
```bash
plink -batch -pw alpine root@192.168.1.8 "uname -a && free"
```

### Paso 2: Cierre Controlado de la Instancia en Memoria
webOS suspende en memoria las aplicaciones actualizadas en caliente; para que los nuevos binarios y el nuevo `appinfo.json` se carguen limpiamente, se debe cerrar la aplicación previa:
```bash
plink -batch -pw alpine root@192.168.1.8 "luna-send -n 1 -w 2000 palm://com.webos.applicationManager/closeByAppId '{\"id\":\"com.lennylxx.iptv\"}'"
```

### Paso 3: Instalación del Nuevo IPK
Transferir e instalar el paquete IPK mediante la herramienta oficial o el instalador del sistema:
```bash
# Opción A: Mediante CLI de desarrollo en PC
npx -p @webos-tools/cli ares-install --device LG-TV AUDIT_REPORTS/MISSION_2_2/package/com.lennylxx.iptv_1.17.0_all.ipk

# Opción B: Copia y despliegue por SSH en directorio de desarrollo
pscp -pw alpine AUDIT_REPORTS/MISSION_2_2/package/com.lennylxx.iptv_1.17.0_all.ipk root@192.168.1.8:/tmp/com.lennylxx.iptv_1.17.0_all.ipk
plink -batch -pw alpine root@192.168.1.8 "opkg install /tmp/com.lennylxx.iptv_1.17.0_all.ipk"
```

### Paso 4: Verificación Post-Instalación
1. Confirmar archivos desplegados:
   ```bash
   plink -batch -pw alpine root@192.168.1.8 "cat /media/developer/apps/usr/palm/applications/com.lennylxx.iptv/appinfo.json"
   ```
   *Criterio de éxito:* Debe mostrar `"inspectable": false`.
2. Lanzar la aplicación en frío:
   ```bash
   plink -batch -pw alpine root@192.168.1.8 "luna-send -n 1 -w 2000 palm://com.webos.applicationManager/launch '{\"id\":\"com.lennylxx.iptv\"}'"
   ```
3. Comprobar procesos en ejecución:
   ```bash
   plink -batch -pw alpine root@192.168.1.8 "ps aux | grep -E 'WebAppMgr|iptv'"
   ```
4. Comprobar catálogo CDP en puerto 9998:
   ```bash
   curl -s http://192.168.1.8:9998/json/list
   ```
   *Criterio de éxito:* `com.lennylxx.iptv` no debe figurar en la lista de páginas inspeccionables.

---

## 3. Condiciones de Parada Inmediata

Detener el procedimiento y proceder al Rollback si:
1. El comando de instalación reporta un código de error distinto de 0.
2. La aplicación no inicia o entra en bucle de cierre al lanzarse.
3. El servicio Node.js en segundo plano no se levanta o se reinicia continuamente.
4. El televisor muestra mensajes de falta de espacio en `/media/developer`.
