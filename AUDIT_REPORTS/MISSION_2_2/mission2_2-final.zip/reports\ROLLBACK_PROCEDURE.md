# Procedimiento de Rollback Inmediato a Versión M2
## Misión M2.2 — webOS IPTV Player (LG 65UM7400PDA)
**Fecha:** 30 de Octubre de 2026  
**Paquete de Retorno Seguro:** `AUDIT_REPORTS/MISSION_2/package/com.lennylxx.iptv_1.17.0_all.ipk`  

---

## 1. Justificación y Criterios de Activación del Rollback

El rollback se activará de inmediato si, tras un intento de instalación en el televisor físico:
- Se pierde la reproducción funcional de los canales HLS o DASH.
- Se producen bloqueos de la interfaz de usuario con el mando a distancia.
- El servicio Luna experimenta caídas recurrentes.
- Se detecta cualquier comportamiento anómalo que comprometa la estabilidad del dispositivo.

---

## 2. Paquete de Respaldo Inmutable

El paquete de la versión anterior que cuenta con reproducción HLS y DASH 100% probada en el hardware real se encuentra resguardado localmente:
- **Ruta:** `AUDIT_REPORTS/MISSION_2/package/com.lennylxx.iptv_1.17.0_all.ipk`
- **Tamaño:** 733.772 bytes
- **SHA-256:** `253648B348F1E5B16E073B07786FBE07A1B68B44026ADFF453B163003CEE9CD5`

---

## 3. Instrucciones de Reinstalación del Paquete Anterior

### Paso 1: Cerrar la Instancia Actual
```bash
plink -batch -pw alpine root@192.168.1.8 "luna-send -n 1 -w 2000 palm://com.webos.applicationManager/closeByAppId '{\"id\":\"com.lennylxx.iptv\"}'"
```

### Paso 2: Reinstalar el IPK Aprobado de M2
```bash
# Transferencia al directorio temporal
pscp -pw alpine AUDIT_REPORTS/MISSION_2/package/com.lennylxx.iptv_1.17.0_all.ipk root@192.168.1.8:/tmp/rollback_iptv.ipk

# Instalación limpia sobreescribiendo la versión previa
plink -batch -pw alpine root@192.168.1.8 "opkg install --force-reinstall /tmp/rollback_iptv.ipk && rm /tmp/rollback_iptv.ipk"
```

### Paso 3: Reinicio en Frío y Verificación de Estado
```bash
# Relanzar aplicación
plink -batch -pw alpine root@192.168.1.8 "luna-send -n 1 -w 2000 palm://com.webos.applicationManager/launch '{\"id\":\"com.lennylxx.iptv\"}'"

# Confirmar procesos activos
plink -batch -pw alpine root@192.168.1.8 "ps aux | grep -E 'WebAppMgr|iptv'"
```

El estado funcional previo queda totalmente restaurado en menos de 60 segundos sin afectar particiones del sistema ni datos de configuración del televisor.
