import { createServer, IncomingMessage, ServerResponse, Server } from 'http';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';

export interface TestServerOptions {
  port?: number;
  host?: string;
  fixturesDir?: string;
}

export const MIME_TYPES: Record<string, string> = {
  '.mp4': 'video/mp4',
  '.m4v': 'video/mp4',
  '.m3u': 'application/x-mpegurl',
  '.m3u8': 'application/vnd.apple.mpegurl',
  '.ts': 'video/mp2t',
  '.json': 'application/json',
  '.xml': 'application/xml',
};

/**
 * Strict whitelist of allowed media fixture files.
 * The test server will strictly refuse to serve any file not in this whitelist.
 */
export const ALLOWED_FIXTURE_FILES = new Set([
  'synthetic_test.mp4',
  'synthetic_test.m3u',
]);

/**
 * Detect non-internal LAN IPv4 address (e.g. 192.168.x.x)
 */
export function getLanIp(): string {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    const list = interfaces[name];
    if (!list) continue;
    for (const iface of list) {
      if (iface.family === 'IPv4' && !iface.internal) {
        if (iface.address.startsWith('192.168.')) {
          return iface.address;
        }
      }
    }
  }
  for (const name of Object.keys(interfaces)) {
    const list = interfaces[name];
    if (!list) continue;
    for (const iface of list) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

/**
 * Parse standard HTTP byte Range header.
 */
export function parseRange(
  rangeHeader: string,
  fileSize: number,
): { start: number; end: number } | 'invalid' | null {
  if (!rangeHeader || !rangeHeader.startsWith('bytes=')) {
    return null;
  }
  const parts = rangeHeader.slice(6).split('-');
  if (parts.length !== 2) return 'invalid';

  const rawStart = parts[0].trim();
  const rawEnd = parts[1].trim();

  let start: number;
  let end: number;

  if (rawStart === '') {
    const suffix = parseInt(rawEnd, 10);
    if (isNaN(suffix) || suffix <= 0) return 'invalid';
    start = Math.max(0, fileSize - suffix);
    end = fileSize - 1;
  } else {
    start = parseInt(rawStart, 10);
    if (isNaN(start) || start < 0) return 'invalid';
    if (rawEnd === '') {
      end = fileSize - 1;
    } else {
      end = parseInt(rawEnd, 10);
      if (isNaN(end) || end < start) return 'invalid';
    }
  }

  if (start >= fileSize) {
    return 'invalid';
  }
  end = Math.min(end, fileSize - 1);
  return { start, end };
}

/**
 * Creates the restricted media test server.
 */
export function createTestServer(options: TestServerOptions = {}): Server {
  const baseDir = path.resolve(options.fixturesDir || path.join(process.cwd(), 'scripts', 'fixtures'));

  return createServer((req: IncomingMessage, res: ServerResponse) => {
    // CORS headers for testing
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { 'Content-Type': 'text/plain' });
      res.end('Method Not Allowed');
      return;
    }

    const rawReqUrl = req.url || '/';
    // Reject path traversal attempts immediately
    if (rawReqUrl.includes('..') || rawReqUrl.toLowerCase().includes('%2e%2e')) {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      res.end('Forbidden: Path Traversal Detected');
      return;
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawReqUrl, `http://${req.headers.host || 'localhost'}`);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Bad Request');
      return;
    }

    let rawPath = parsedUrl.pathname;
    try {
      rawPath = decodeURIComponent(rawPath);
    } catch {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Bad Request');
      return;
    }

    let targetFilename = rawPath.replace(/^\/+/, '');
    if (targetFilename === '') {
      targetFilename = 'synthetic_test.mp4';
    }

    // Strict whitelist enforcement: reject any unapproved file requests
    if (!ALLOWED_FIXTURE_FILES.has(targetFilename)) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not Found: Unapproved fixture file');
      return;
    }

    const safePath = path.resolve(baseDir, targetFilename);
    if (!safePath.startsWith(baseDir + path.sep)) {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      res.end('Forbidden: Path Traversal Detected');
      return;
    }

    fs.stat(safePath, (err, stats) => {
      if (err || !stats.isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');
        return;
      }

      const ext = path.extname(safePath).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      const fileSize = stats.size;

      const rangeHeader = req.headers.range;
      if (rangeHeader) {
        const range = parseRange(rangeHeader, fileSize);
        if (range === 'invalid') {
          res.writeHead(416, {
            'Content-Range': `bytes */${fileSize}`,
            'Content-Type': 'text/plain',
          });
          res.end('Requested Range Not Satisfiable');
          return;
        }

        if (range) {
          const chunkSize = range.end - range.start + 1;
          res.writeHead(206, {
            'Content-Range': `bytes ${range.start}-${range.end}/${fileSize}`,
            'Accept-Ranges': 'bytes',
            'Content-Length': chunkSize,
            'Content-Type': contentType,
          });

          if (req.method === 'HEAD') {
            res.end();
            return;
          }

          const stream = fs.createReadStream(safePath, { start: range.start, end: range.end });
          stream.on('error', () => {
            if (!res.headersSent) {
              res.writeHead(500);
            }
            res.end();
          });
          stream.pipe(res);
          return;
        }
      }

      // Full file GET
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': contentType,
        'Accept-Ranges': 'bytes',
      });

      if (req.method === 'HEAD') {
        res.end();
        return;
      }

      const fullStream = fs.createReadStream(safePath);
      fullStream.on('error', () => {
        if (!res.headersSent) {
          res.writeHead(500);
        }
        res.end();
      });
      fullStream.pipe(res);
    });
  });
}

/**
 * Parse CLI options for host, port and interface.
 */
export function parseServerCliArgs(argv: string[]): { host: string; port: number } {
  let host = process.env.TEST_SERVER_HOST || '127.0.0.1';
  let port = Number(process.env.TEST_SERVER_PORT) || 8088;

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--host' && argv[i + 1]) {
      host = argv[++i];
    } else if (arg === '--port' && argv[i + 1]) {
      port = parseInt(argv[++i], 10) || 8088;
    } else if (arg === '--lan') {
      host = getLanIp();
    }
  }

  if (host === 'lan') {
    host = getLanIp();
  }

  return { host, port };
}

// Standalone execution: strictly requires user to invoke it; never binds to 0.0.0.0 by default.
if (process.argv[1] && process.argv[1].endsWith('test-server.ts')) {
  const { host, port } = parseServerCliArgs(process.argv.slice(2));
  const server = createTestServer({ host, port });

  server.listen(port, host, () => {
    console.log(`[TestServer] Bound strictly to http://${host}:${port}`);
    console.log(`[TestServer] Available stream: http://${host}:${port}/synthetic_test.mp4`);
    console.log(`[TestServer] Allowed fixtures: ${Array.from(ALLOWED_FIXTURE_FILES).join(', ')}`);
    console.log('[TestServer] Press Ctrl+C (SIGINT) to stop the server cleanly.');
  });

  const shutdown = () => {
    console.log('\n[TestServer] Stopping server...');
    server.close(() => {
      console.log('[TestServer] Server stopped cleanly.');
      process.exit(0);
    });
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
