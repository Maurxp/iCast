import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import * as http from 'http';
import { parseRange, createTestServer, parseServerCliArgs, getLanIp, ALLOWED_FIXTURE_FILES } from '../../scripts/test-server';

describe('test-server CLI argument parsing and binding options', () => {
  it('defaults to 127.0.0.1 and port 8088 when no arguments given', () => {
    const { host, port } = parseServerCliArgs([]);
    expect(host).toBe('127.0.0.1');
    expect(port).toBe(8088);
  });

  it('parses explicit --host and --port', () => {
    const { host, port } = parseServerCliArgs(['--host', '192.168.1.100', '--port', '9000']);
    expect(host).toBe('192.168.1.100');
    expect(port).toBe(9000);
  });

  it('resolves --lan to non-internal LAN IP', () => {
    const { host } = parseServerCliArgs(['--lan']);
    const expected = getLanIp();
    expect(host).toBe(expected);
    expect(host).not.toBe('0.0.0.0');
  });

  it('resolves --host lan to non-internal LAN IP', () => {
    const { host } = parseServerCliArgs(['--host', 'lan']);
    expect(host).toBe(getLanIp());
  });
});

describe('test-server range parsing', () => {
  const size = 1000;

  it('returns null when no range is provided', () => {
    expect(parseRange('', size)).toBeNull();
  });

  it('parses explicit start and end', () => {
    expect(parseRange('bytes=0-499', size)).toEqual({ start: 0, end: 499 });
  });

  it('parses open-ended start', () => {
    expect(parseRange('bytes=500-', size)).toEqual({ start: 500, end: 999 });
  });

  it('parses suffix range', () => {
    expect(parseRange('bytes=-200', size)).toEqual({ start: 800, end: 999 });
  });

  it('returns invalid when start >= fileSize', () => {
    expect(parseRange('bytes=1000-', size)).toBe('invalid');
  });

  it('returns invalid when start > end', () => {
    expect(parseRange('bytes=500-400', size)).toBe('invalid');
  });

  it('returns invalid on non-numeric values', () => {
    expect(parseRange('bytes=abc-def', size)).toBe('invalid');
  });
});

describe('test-server HTTP requests', () => {
  let server: http.Server;
  let serverPort: number;

  beforeAll(async () => {
    server = createTestServer();
    await new Promise<void>((resolve) => {
      server.listen(0, '127.0.0.1', () => {
        const addr = server.address();
        if (addr && typeof addr === 'object') {
          serverPort = addr.port;
        }
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  });

  function request(
    options: http.RequestOptions,
  ): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: Buffer }> {
    return new Promise((resolve, reject) => {
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: serverPort,
          ...options,
        },
        (res) => {
          const chunks: Buffer[] = [];
          res.on('data', (c) => chunks.push(Buffer.from(c)));
          res.on('end', () => {
            resolve({
              statusCode: res.statusCode || 0,
              headers: res.headers,
              body: Buffer.concat(chunks),
            });
          });
        },
      );
      req.on('error', reject);
      req.end();
    });
  }

  it('serves synthetic_test.mp4 with 200 OK and correct headers', async () => {
    const res = await request({ path: '/synthetic_test.mp4', method: 'GET' });
    expect(res.statusCode).toBe(200);
    expect(res.headers['content-type']).toBe('video/mp4');
    expect(res.headers['accept-ranges']).toBe('bytes');
    expect(Number(res.headers['content-length'])).toBeGreaterThan(900000);
    expect(res.body.length).toBe(Number(res.headers['content-length']));
  });

  it('serves 206 Partial Content for byte range request', async () => {
    const res = await request({
      path: '/synthetic_test.mp4',
      method: 'GET',
      headers: { Range: 'bytes=0-99' },
    });
    expect(res.statusCode).toBe(206);
    expect(res.headers['content-type']).toBe('video/mp4');
    expect(res.headers['content-length']).toBe('100');
    expect(res.headers['content-range']).toMatch(/^bytes 0-99\/\d+$/);
    expect(res.body.length).toBe(100);
  });

  it('serves 206 Partial Content for suffix range request', async () => {
    const res = await request({
      path: '/synthetic_test.mp4',
      method: 'GET',
      headers: { Range: 'bytes=-50' },
    });
    expect(res.statusCode).toBe(206);
    expect(res.headers['content-length']).toBe('50');
    expect(res.body.length).toBe(50);
  });

  it('serves 416 Range Not Satisfiable for out of bounds range', async () => {
    const res = await request({
      path: '/synthetic_test.mp4',
      method: 'GET',
      headers: { Range: 'bytes=99999999-999999999' },
    });
    expect(res.statusCode).toBe(416);
    expect(res.headers['content-range']).toMatch(/^bytes \*\/\d+$/);
  });

  it('responds to HEAD requests with empty body and correct content length', async () => {
    const res = await request({ path: '/synthetic_test.mp4', method: 'HEAD' });
    expect(res.statusCode).toBe(200);
    expect(res.headers['content-type']).toBe('video/mp4');
    expect(Number(res.headers['content-length'])).toBeGreaterThan(900000);
    expect(res.body.length).toBe(0);
  });

  it('blocks path traversal attempts with 403 Forbidden', async () => {
    const res = await request({ path: '/%2e%2e/%2e%2e/package.json', method: 'GET' });
    expect(res.statusCode).toBe(403);
  });

  it('strictly rejects unapproved files outside the whitelist with 404', async () => {
    const res = await request({ path: '/unapproved.mp4', method: 'GET' });
    expect(res.statusCode).toBe(404);
    expect(res.body.toString()).toContain('Unapproved fixture file');
  });

  it('serves approved synthetic_test.m3u playlist with 200 OK', async () => {
    const res = await request({ path: '/synthetic_test.m3u', method: 'GET' });
    expect(res.statusCode).toBe(200);
    expect(res.headers['content-type']).toBe('application/x-mpegurl');
    expect(res.body.toString()).toContain('#EXTM3U');
  });

  it('exposes ALLOWED_FIXTURE_FILES with only synthetic_test.mp4 and synthetic_test.m3u', () => {
    expect(ALLOWED_FIXTURE_FILES.has('synthetic_test.mp4')).toBe(true);
    expect(ALLOWED_FIXTURE_FILES.has('synthetic_test.m3u')).toBe(true);
    expect(ALLOWED_FIXTURE_FILES.size).toBe(2);
  });
});
