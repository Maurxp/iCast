// @vitest-environment jsdom
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import type { ChannelCycleMode, ManualEpgSource, PlaylistEntry, TzMode, XtreamLiveCategorySnapshot } from '../types';
import type { AnimationMode } from '../services/motion-service';
import type { XtreamAccountInfo, XtreamLiveCategory } from '../services/xtream-client';

const {
  state,
  storageMock,
  cacheMock,
  themeMock,
  toastMock,
  setupMock,
  uploadMock,
  xtreamMock,
  healthMock,
  motionMock,
} = vi.hoisted(() => {
  const state = {
    playlists: [] as {
      id?: string;
      name: string;
      url: string;
      source?: 'upload' | 'url' | 'xtream';
      enabled?: boolean;
      count?: number;
      xtream?: {
        username: string;
        password: string;
        liveCategories?: { mode: 'include' | 'exclude'; ids: string[] };
      };
    }[],
    manualEpgSources: [] as ManualEpgSource[],
    autoPlay: false,
    livePreview: false,
    animationMode: 'reduced' as AnimationMode,
    theme: 'midnight' as string,
    overlayStyle: 'dark' as string,
    textSize: '100' as string,
    tzMode: 'device' as TzMode,
    channelCycleMode: 'global' as ChannelCycleMode,
    liveReconnectAttempts: 3,
    numberEntryOsdTimeoutMs: 1200,
    playerOsdTimeoutMs: 5000,
    playlistRefreshHours: 6,
    epgRefreshHours: 6,
    xtreamCatalogRefreshHours: 6,
    showHidden: false,
    tzOffset: null as number | null,
    epgOffsets: {} as Record<string, number>,
    locale: 'system' as const,
    onlineSubtitles: {
      preferredLanguage: '',
      subdl: { apiKey: '' },
      opensubtitles: { apiKey: '', username: '', password: '', token: '', tokenTs: 0 },
      assrt: { apiKey: '' },
    },
  };
  return {
    state,
    cacheMock: {
      clearAllCachedData: vi.fn(async () => {}),
      getCacheUsage: vi.fn(async () => ({
        total: { bytes: 438 * 1024 * 1024, entries: 12 },
        categories: {
          playlist: { bytes: 19 * 1024 * 1024, entries: 1 },
          epg: { bytes: 92 * 1024 * 1024, entries: 2 },
          catalog: { bytes: 286 * 1024 * 1024, entries: 7 },
          subtitle: { bytes: 41 * 1024 * 1024, entries: 2 },
          health: { bytes: 0, entries: 0 },
          search: { bytes: 3 * 1024 * 1024, entries: 2 },
        },
        budgetBytes: 1024 * 1024 * 1024,
        originUsageBytes: null,
        quotaBytes: null,
      })),
    },
    themeMock: { previewTheme: vi.fn(), applyTheme: vi.fn(), initTheme: vi.fn(), applyTextSize: vi.fn()     },
    motionMock: {
      applyAnimationMode: vi.fn(),
    },
    storageMock: {
      getPlaylists: vi.fn(() => state.playlists),
      getManualEpgSources: vi.fn(() => state.manualEpgSources.map(source => ({
        ...source,
        playlistIds: source.playlistIds.slice(),
      }))),
      getAutoPlay: vi.fn(() => state.autoPlay),
      getLivePreview: vi.fn(() => state.livePreview),
      getAnimationMode: vi.fn(() => state.animationMode),
      getTheme: vi.fn(() => state.theme),
      getOverlayStyle: vi.fn(() => state.overlayStyle),
      getTextSize: vi.fn(() => state.textSize),
      getTzMode: vi.fn(() => state.tzMode),
      getChannelCycleMode: vi.fn(() => state.channelCycleMode),
      getLiveReconnectAttempts: vi.fn(() => state.liveReconnectAttempts),
      getNumberEntryOsdTimeoutMs: vi.fn(() => state.numberEntryOsdTimeoutMs),
      getPlayerOsdTimeoutMs: vi.fn(() => state.playerOsdTimeoutMs),
      getPlaylistRefreshIntervalHours: vi.fn(() => state.playlistRefreshHours),
      getEpgRefreshIntervalHours: vi.fn(() => state.epgRefreshHours),
      getXtreamCatalogRefreshIntervalHours: vi.fn(
        () => state.xtreamCatalogRefreshHours,
      ),
      getEpgTzOffset: vi.fn(() => state.tzOffset),
      getEpgOffsets: vi.fn(() => ({ ...state.epgOffsets })),
      getLocalePreference: vi.fn(() => state.locale),
      getOnlineSubtitleConfig: vi.fn(() => state.onlineSubtitles),
      getSelectedXtreamAccountId: vi.fn(() => null),
      getLiveCategorySnapshot: vi.fn(() => null),
      setLiveCategorySnapshot: vi.fn(),
      getShowHiddenChannels: vi.fn(() => state.showHidden),
      setShowHiddenChannels: vi.fn((v: boolean) => { state.showHidden = v; }),
      getChannelCustomization: vi.fn(() => null),
      setChannelCustomization: vi.fn(),
      clearChannelCustomization: vi.fn(),
      setPlaylists: vi.fn(),
      setManualEpgSources: vi.fn((sources: ManualEpgSource[]) => {
        state.manualEpgSources = sources.map(source => ({
          ...source,
          playlistIds: source.playlistIds.slice(),
        }));
        return true;
      }),
      setAutoPlay: vi.fn(),
      setLivePreview: vi.fn((value: boolean) => { state.livePreview = value; }),
      setAnimationMode: vi.fn((value: AnimationMode) => { state.animationMode = value; }),
      setTheme: vi.fn((id: string) => { state.theme = id; }),
      setOverlayStyle: vi.fn((s: string) => { state.overlayStyle = s; }),
      setTextSize: vi.fn((s: string) => { state.textSize = s; }),
      setTzMode: vi.fn(),
      setChannelCycleMode: vi.fn((m: ChannelCycleMode) => { state.channelCycleMode = m; }),
      setLiveReconnectAttempts: vi.fn((attempts: number) => {
        state.liveReconnectAttempts = attempts;
      }),
      setNumberEntryOsdTimeoutMs: vi.fn((timeout: number) => {
        state.numberEntryOsdTimeoutMs = timeout;
      }),
      setPlayerOsdTimeoutMs: vi.fn((timeout: number) => {
        state.playerOsdTimeoutMs = timeout;
      }),
      setPlaylistRefreshIntervalHours: vi.fn((hours: number) => {
        state.playlistRefreshHours = hours;
      }),
      setEpgRefreshIntervalHours: vi.fn((hours: number) => {
        state.epgRefreshHours = hours;
      }),
      setXtreamCatalogRefreshIntervalHours: vi.fn((hours: number) => {
        state.xtreamCatalogRefreshHours = hours;
      }),
      setEpgOffsets: vi.fn((offsets: Record<string, number>) => {
        state.epgOffsets = { ...offsets };
      }),
      migrateCatchupEpgOffsets: vi.fn(),
      setLocalePreference: vi.fn(),
      setOnlineSubtitleConfig: vi.fn((cfg: any) => { state.onlineSubtitles = cfg; }),
      remove: vi.fn(),
      clearRecentlyWatched: vi.fn(),
      clearWatchlist: vi.fn(),
      clearResumeList: vi.fn(),
      getResumeList: vi.fn((_accountId: string): unknown[] => []),
      getWatchlist: vi.fn((_accountId: string, _kind: 'vod' | 'series'): unknown[] => []),
    },
    toastMock: { showToast: vi.fn() },
    setupMock: {
      // Default to "service unreachable" so render's async refreshSetupInfo is a
      // no-op for existing tests. Tests can override via mockResolvedValueOnce.
      getInfo: vi.fn(async () => null),
    },
    uploadMock: {
      remove: vi.fn(async () => true),
      reconcile: vi.fn(async () => undefined),
    },
    // Default to "unverifiable" so a stray Check is inert; tests opt in with
    // mockResolvedValueOnce. Never touches the network.
    xtreamMock: {
      getAccountInfo: vi.fn(async (): Promise<XtreamAccountInfo | null> => null),
      getLiveCategories: vi.fn(async (): Promise<XtreamLiveCategory[]> => []),
    },
    healthMock: {
      getSummary: vi.fn((channels: unknown[]) => ({
        total: channels.length,
        unknown: channels.length,
        healthy: 0,
        suspect: 0,
        unavailable: 0,
      })),
      checkAll: vi.fn(async () => ({
        total: 0,
        unknown: 0,
        healthy: 0,
        suspect: 0,
        unavailable: 0,
      })),
      reset: vi.fn(),
    },
  };
});

vi.mock('../services/storage-service', () => ({
  NUMBER_ENTRY_OSD_TIMEOUT_MS_OPTIONS: [1200, 1800, 2500, 3000, 3500],
  LIVE_RECONNECT_ATTEMPT_OPTIONS: [0, 1, 2, 3, 4, 5],
  PLAYER_OSD_TIMEOUT_MS_OPTIONS: [3000, 5000, 8000, 10000, 12000],
  REFRESH_INTERVAL_HOUR_OPTIONS: [0, 1, 3, 6, 12, 24],
  XTREAM_CATALOG_REFRESH_HOUR_OPTIONS: [1, 3, 6, 12, 24],
  StorageService: storageMock,
}));
vi.mock('../services/theme-service', () => themeMock);
vi.mock('../services/motion-service', () => ({
  ANIMATION_MODES: ['essential', 'reduced', 'full'],
  applyAnimationMode: motionMock.applyAnimationMode,
}));
vi.mock('../services/idb-cache', () => cacheMock);
vi.mock('./toast', () => ({ showToast: toastMock.showToast }));
vi.mock('../services/xtream-client', () => ({
  createXtreamClient: () => ({
    getAccountInfo: xtreamMock.getAccountInfo,
    getLiveCategories: xtreamMock.getLiveCategories,
  }),
}));
vi.mock('../services/upload-client', () => ({
  UploadClient: uploadMock,
  uploadIdFromUrl: (url: string) => {
    const m = url.match(/\/uploads\/([^/]+?)(?:\.m3u)?$/i);
    return m ? decodeURIComponent(m[1]) : '';
  },
}));
vi.mock('../services/reminder-service', () => ({
  ReminderService: {
    backfillSourceIds: vi.fn(),
    migrateEpgOffsets: vi.fn(),
    listManageable: vi.fn(() => []),
  },
}));
vi.mock('../services/setup-client', () => ({ SetupClient: setupMock }));
vi.mock('../services/channel-health', () => ({ ChannelHealthService: healthMock }));

import { Settings, liveCategoriesButtonContent } from './settings';
import { setLocale } from '../i18n';
import { PlaylistService } from '../services/playlist-service';
import { EpgService } from '../services/epg-service';
import { channelKey, legacyChannelKey } from '../utils/channel';
import { morph } from '../utils/morph';
import { Focus } from '../navigation/focus-scope';
import { CONFIG } from '../config';
import { ParentalControlService } from '../services/parental-control';

let container: HTMLElement;
let onSave: ReturnType<typeof vi.fn>;
let onChannelsChanged: ReturnType<typeof vi.fn>;
let settings: Settings;

beforeEach(() => {
  Element.prototype.scrollIntoView = vi.fn();
  state.playlists = [];
  state.manualEpgSources = [];
  state.autoPlay = false;
  state.livePreview = false;
  state.animationMode = 'reduced';
  state.theme = 'midnight';
  state.overlayStyle = 'dark';
  state.textSize = '100';
  state.liveReconnectAttempts = 3;
  state.numberEntryOsdTimeoutMs = 1200;
  state.playerOsdTimeoutMs = 5000;
  state.playlistRefreshHours = 6;
  state.epgRefreshHours = 6;
  state.xtreamCatalogRefreshHours = 6;
  state.epgOffsets = {};
  PlaylistService.epgSources = [];
  PlaylistService.allChannels = [];
  PlaylistService.channels = [];
  storageMock.getSelectedXtreamAccountId.mockReturnValue(null);
  state.onlineSubtitles = {
    preferredLanguage: '',
    subdl: { apiKey: '' },
    opensubtitles: { apiKey: '', username: '', password: '', token: '', tokenTs: 0 },
    assrt: { apiKey: '' },
  };
  vi.clearAllMocks();
  document.body.innerHTML = '';
  container = document.createElement('div');
  document.body.appendChild(container);
  onSave = vi.fn();
  onChannelsChanged = vi.fn();
  settings = new Settings(container, onSave, onChannelsChanged);
  Focus.setBase(() => settings.focusScope);
});

function click(selector: string): void {
  container.querySelector<HTMLElement>(selector)!
    .dispatchEvent(new MouseEvent('click', { bubbles: true }));
}

afterEach(() => Focus.uninstall());

describe('Settings.render', () => {
  it('renders the category sidebar with General first', () => {
    settings.render();
    const labels = Array.from(container.querySelectorAll('.settings-nav-item'))
      .map((item) => item.textContent?.trim());
    expect(labels).toEqual([
      'General',
      'Sources',
      'Program Guide',
      'Appearance',
      'Playback',
      'Online Subtitles',
      'Advanced',
      'Data Management',
    ]);
    const navOrder = Array.from(container.querySelectorAll<HTMLElement>('.settings-nav-item'))
      .map(item => item.dataset.settingsTarget);
    const contentOrder = Array.from(
      container.querySelectorAll<HTMLElement>('.settings-scroll > .settings-category'),
    ).map(item => item.dataset.settingsCategory);
    expect(contentOrder).toEqual(navOrder);
    expect(container.querySelector('.settings-nav-item.active')?.getAttribute('data-settings-target'))
      .toBe('general');
    expect(container.querySelector('.settings-nav-help')?.textContent)
      .toContain('Choose category');
    expect(container.querySelector('.settings-nav-help')?.textContent)
      .toContain('Enter / return');
  });

  it('starts a manual channel health check from the Channels section', async () => {
    PlaylistService.allChannels = [{
      id: 'ch1',
      name: 'Alpha',
      logo: '',
      group: '',
      url: 'http://host/a',
      extras: null,
      playlistIds: [],
      catchup: '',
      catchupSource: '',
      catchupDays: 0,
    }];
    PlaylistService.channels = PlaylistService.allChannels;
    settings.render();

    expect(container.querySelector('.channel-health-summary')?.textContent)
      .toContain('Not checked: 1');
    click('#check-channel-health');

    await vi.waitFor(() => {
      expect(healthMock.checkAll).toHaveBeenCalledWith(
        PlaylistService.allChannels,
        expect.objectContaining({
          signal: expect.any(AbortSignal),
          onProgress: expect.any(Function),
        }),
      );
      expect(toastMock.showToast).toHaveBeenCalledWith('Channel health check complete');
    });
  });

  it('pauses, resumes, and cancels a channel health check', async () => {
    PlaylistService.allChannels = [{
      id: 'ch1',
      name: 'Alpha',
      logo: '',
      group: '',
      url: 'http://host/a',
      extras: null,
      playlistIds: [],
      catchup: '',
      catchupSource: '',
      catchupDays: 0,
    }];
    PlaylistService.channels = PlaylistService.allChannels;
    let options: {
      signal?: AbortSignal;
      waitWhilePaused?: () => Promise<void>;
    } = {};
    let finish: (() => void) | null = null;
    healthMock.checkAll.mockImplementationOnce(async (_channels, value) => {
      options = value;
      await new Promise<void>(resolve => { finish = resolve; });
      return {
        total: 1,
        unknown: 1,
        healthy: 0,
        suspect: 0,
        unavailable: 0,
      };
    });
    settings.render();
    click('#check-channel-health');
    await vi.waitFor(() => expect(container.querySelector('#pause-channel-health')).not.toBeNull());

    click('#pause-channel-health');
    expect(container.querySelector('#pause-channel-health')?.textContent?.trim()).toBe('Continue');
    const resumed = options.waitWhilePaused?.();
    click('#pause-channel-health');
    await resumed;
    expect(container.querySelector('#pause-channel-health')?.textContent?.trim()).toBe('Pause');

    click('#pause-channel-health');
    const cancelled = options.waitWhilePaused?.();
    click('#cancel-channel-health');
    await cancelled;
    expect(options.signal?.aborted).toBe(true);
    finish?.();
    await vi.waitFor(() => expect(container.querySelector('#check-channel-health')).not.toBeNull());
  });

  it('groups language and time zone under General, with autoplay under Playback', () => {
    settings.render();
    expect(container.querySelectorAll('.settings-section > .settings-section-title'))
      .toHaveLength(container.querySelectorAll('.settings-section').length);
    expect(container.querySelector('#app-language')?.closest('[data-settings-category]')
      ?.getAttribute('data-settings-category')).toBe('general');
    expect(container.querySelector('#tz-mode')?.closest('[data-settings-category]')
      ?.getAttribute('data-settings-category')).toBe('guide');
    expect(container.querySelector('#auto-play')?.closest('[data-settings-category]')
      ?.getAttribute('data-settings-category')).toBe('playback');
    expect(container.querySelector('#clear-recently-watched')?.closest('[data-settings-category]')
      ?.getAttribute('data-settings-category')).toBe('data');
    expect(container.querySelector('#settings-general')?.textContent).not.toContain('Display');
    expect(container.querySelector('.settings-section .settings-section')).toBeNull();
  });

  it('opens reminder management from the count-bearing guide entry', () => {
    const onManageReminders = vi.fn();
    settings.focusScope.dispose();
    settings = new Settings(container, onSave, onChannelsChanged, onManageReminders);
    settings.render();

    expect(container.querySelector('#manage-reminders')?.textContent?.trim())
      .toBe('Manage Reminders (0)');
    click('#manage-reminders');
    expect(onManageReminders).toHaveBeenCalledOnce();
  });

  it('shows an empty hint when there are no playlists', () => {
    settings.render();
    expect(container.querySelector('#playlist-entries .empty-hint')?.textContent).toBe('No playlists added yet');
  });

  it('keeps disabled time correction controls visible before an EPG source is loaded', () => {
    settings.render();

    expect(container.querySelector('#epg-offset-source')).not.toBeNull();
    expect(container.querySelector<HTMLButtonElement>(
      '#epg-offset-source .dropdown-trigger',
    )?.disabled).toBe(true);
    expect(container.querySelectorAll('.epg-offset-stepper button:disabled')).toHaveLength(3);
    expect(container.querySelector('#settings-guide')?.textContent)
      .not.toContain('Load the program guide to discover sources');
  });

  it('places the EPG source dropdown and offset buttons in one control row', () => {
    state.manualEpgSources = [{ url: 'http://host/epg.xml', playlistIds: [] }];
    settings.render();

    const controls = container.querySelector('.epg-offset-controls')!;
    expect(controls.children[0]?.id).toBe('epg-offset-source');
    expect(controls.children[1]?.classList.contains('epg-offset-stepper')).toBe(true);
  });

  it('renders a row per configured playlist with its values', () => {
    state.playlists = [{ name: 'P1', url: 'http://a' }, { name: 'P2', url: 'http://b' }];
    state.manualEpgSources = [{ url: 'http://epg', playlistIds: [] }];
    settings.render();
    const names = Array.from(container.querySelectorAll<HTMLInputElement>('.playlist-name'));
    const urls = Array.from(container.querySelectorAll<HTMLInputElement>('.playlist-url'));
    expect(names.map(n => n.value)).toEqual(['P1', 'P2']);
    expect(urls.map(u => u.value)).toEqual(['http://a', 'http://b']);
    expect(container.querySelector<HTMLInputElement>('.manual-epg-url')!.value)
      .toBe('http://epg');
  });

  it('uses type="url" on URL inputs so the webOS keyboard shows URL keys', () => {
    state.playlists = [
      { id: 'p1', name: 'P1', url: 'http://a', source: 'url' },
      { id: 'x1', name: 'X1', url: 'http://host:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
    ];
    state.manualEpgSources = [{ url: 'http://epg', playlistIds: [] }];
    settings.render();
    click('#add-playlist');

    const urlInputs = Array.from(container.querySelectorAll<HTMLInputElement>(
      '.playlist-url, .xtream-url, .manual-epg-url'));
    expect(urlInputs).toHaveLength(4);
    expect(urlInputs.map(input => input.type)).toEqual(['url', 'url', 'url', 'url']);
    expect(container.querySelector<HTMLInputElement>('.playlist-name')!.type).toBe('text');
  });

  it('persists a disabled M3U source without deleting it', () => {
    state.playlists = [{ id: 'p1', name: 'P1', url: 'http://a', source: 'url' }];
    settings.render();
    click('#playlist-entries .source-toggle');
    expect(container.querySelector('#playlist-entries [data-source-entry]')
      ?.classList.contains('source-disabled')).toBe(true);

    click('#save-settings');

    expect(storageMock.setPlaylists).toHaveBeenCalledWith([
      { id: 'p1', name: 'P1', url: 'http://a', source: 'url', enabled: false },
    ]);
    expect(onSave).toHaveBeenCalledWith('reload');
  });

  it('asks the parental guard before turning a source off, not on', () => {
    const authorize = vi.fn();
    container.remove();
    container = document.createElement('div');
    document.body.appendChild(container);
    settings.focusScope.dispose();
    settings = new Settings(
      container, onSave, onChannelsChanged, undefined, undefined, undefined, authorize);
    state.playlists = [{ id: 'p1', name: 'P1', url: 'http://a', source: 'url' }];
    settings.render();
    const entry = () => container.querySelector('#playlist-entries [data-source-entry]')!;

    click('#playlist-entries .source-toggle');
    expect(authorize).toHaveBeenCalledWith('p1', expect.any(Function), true);
    expect(entry().classList.contains('source-disabled')).toBe(false);

    authorize.mock.calls[0][1]();
    expect(entry().classList.contains('source-disabled')).toBe(true);
    click('#playlist-entries .source-toggle');
    expect(authorize).toHaveBeenCalledTimes(1);
    expect(entry().classList.contains('source-disabled')).toBe(false);
  });

  it('reflects the auto-play state on the toggle', () => {
    state.autoPlay = true;
    settings.render();
    expect(container.querySelector('#auto-play .toggle-option.active')!.getAttribute('data-value')).toBe('on');
  });

  it('renders animation, reconnect, and refresh controls under Advanced', () => {
    settings.render();
    const advanced = container.querySelector('#settings-advanced')!;
    expect(advanced.querySelector('.settings-section-title')?.textContent).toBe('Advanced');
    const items = advanced.querySelectorAll('.settings-advanced-row');
    expect(items).toHaveLength(6);
    expect(Array.from(advanced.querySelectorAll('.settings-advanced-group'))
      .map(group => group.textContent?.trim())
      .filter(Boolean))
      .toEqual(['Interface', 'Playback', 'On-screen display', 'Background refresh']);
    expect(items[0].querySelector('.settings-item-title')?.textContent)
      .toBe('Animation mode');
    expect(items[0].querySelector('.settings-advanced-control')?.children)
      .toHaveLength(1);
    expect(Array.from(container.querySelectorAll<HTMLElement>(
      '#animation-mode .toggle-option',
    )).map(option => option.dataset.value))
      .toEqual(['essential', 'reduced', 'full']);
    expect(container.querySelector('#animation-mode .toggle-option.active')
      ?.getAttribute('data-value')).toBe('reduced');
    expect(items[1].querySelector('.settings-item-title')?.textContent)
      .toBe('Live reconnect attempts');
    expect(items[1].querySelector('.settings-advanced-control')?.children).toHaveLength(1);
    expect(container.querySelector('#live-reconnect-attempts')?.getAttribute('data-value'))
      .toBe('3');
    expect(Array.from(container.querySelectorAll<HTMLElement>(
      '#live-reconnect-attempts [data-dropdown-value]',
    )).map(option => option.dataset.dropdownValue))
      .toEqual(['0', '1', '2', '3', '4', '5']);
    expect(items[2].querySelector('.settings-item-title')?.textContent)
      .toBe('Number Entry OSD timeout');
    expect(container.querySelector('#number-entry-osd-timeout')?.getAttribute('data-value'))
      .toBe('1200');
    expect(Array.from(container.querySelectorAll<HTMLElement>(
      '#number-entry-osd-timeout [data-dropdown-value]',
    )).map(option => option.textContent))
      .toEqual(['1.2 seconds', '1.8 seconds', '2.5 seconds', '3 seconds', '3.5 seconds']);
    expect(items[3].querySelector('.settings-item-title')?.textContent)
      .toBe('Player OSD auto-hide delay');
    expect(container.querySelector('#player-osd-timeout')?.getAttribute('data-value'))
      .toBe('5000');
    expect(Array.from(container.querySelectorAll<HTMLElement>(
      '#player-osd-timeout [data-dropdown-value]',
    )).map(option => option.textContent))
      .toEqual(['3 seconds', '5 seconds', '8 seconds', '10 seconds', '12 seconds']);
    expect(container.querySelector('#playlist-refresh-interval')
      ?.getAttribute('data-value')).toBe('6');
    expect(container.querySelector('#epg-refresh-interval')
      ?.getAttribute('data-value')).toBe('6');
    expect(Array.from(container.querySelectorAll<HTMLElement>(
      '#playlist-refresh-interval [data-dropdown-value]',
    )).map(option => option.dataset.dropdownValue))
      .toEqual(['0', '1', '3', '6', '12', '24']);
    expect(Array.from(container.querySelectorAll<HTMLElement>(
      '#playlist-refresh-interval [data-dropdown-value]',
    )).map(option => option.textContent))
      .toEqual(['Off', '1 hour', '3 hours', '6 hours', '12 hours', '24 hours']);
    expect(container.querySelector('#xtream-catalog-refresh-interval')).toBeNull();
  });

  it('shows the Xtream catalog refresh interval only for an enabled account', () => {
    state.playlists = [{
      id: 'x1',
      name: 'Account',
      url: 'http://host',
      source: 'xtream',
      xtream: { username: 'u', password: 'p' },
    }];

    settings.render();

    expect(container.querySelectorAll('#settings-advanced .settings-advanced-row'))
      .toHaveLength(7);
    expect(container.querySelector('#xtream-catalog-refresh-interval')
      ?.getAttribute('data-value')).toBe('6');
    expect(Array.from(container.querySelectorAll<HTMLElement>(
      '#xtream-catalog-refresh-interval [data-dropdown-value]',
    )).map(option => option.dataset.dropdownValue))
      .toEqual(['1', '3', '6', '12', '24']);
  });

  it('persists and applies the selected animation mode', () => {
    settings.render();
    click('#animation-mode [data-value="full"]');
    click('#save-settings');
    expect(storageMock.setAnimationMode).toHaveBeenCalledWith('full');
    expect(motionMock.applyAnimationMode).toHaveBeenCalledWith('full');
  });

  it('persists the selected number entry and player OSD timeouts', () => {
    settings.render();
    click('#number-entry-osd-timeout [data-dropdown-value="1800"]');
    click('#player-osd-timeout [data-dropdown-value="8000"]');
    click('#save-settings');
    expect(storageMock.setNumberEntryOsdTimeoutMs).toHaveBeenCalledWith(1800);
    expect(storageMock.setPlayerOsdTimeoutMs).toHaveBeenCalledWith(8000);
  });

  // Left moves within a row by measuring peers, and a collapsed control has no
  // vertical overlap with its row, so the overlap guard alone rejects it. With
  // the leading swatch collapsed the second one has no peer to its left, so
  // left leaves the row for the category sidebar.
  it('left skips a collapsed peer instead of focusing it', () => {
    settings.render();

    const swatches = Array.from(container.querySelectorAll<HTMLElement>('.theme-swatch'));
    expect(swatches.length).toBeGreaterThan(1);
    swatches[1].dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));

    const original = Element.prototype.getBoundingClientRect;
    Element.prototype.getBoundingClientRect = function stub(this: Element): DOMRect {
      const index = swatches.indexOf(this as HTMLElement);
      if (index < 0) return { width: 0, height: 0, top: 0, left: 0, bottom: 0, right: 0 } as DOMRect;
      if (index === 0) return { width: 0, height: 0, top: 0, left: 0, bottom: 0, right: 0 } as DOMRect;
      const left = 110 * index;
      return { width: 100, height: 100, top: 0, left, bottom: 100, right: left + 100 } as DOMRect;
    };
    try {
      settings.handleAction('left');
    } finally {
      Element.prototype.getBoundingClientRect = original;
    }

    expect(swatches[0].classList.contains('focused')).toBe(false);
    expect(container.querySelector('.settings-nav-item.focused')).not.toBeNull();
  });

  it('shows and restores the empty hint for manual EPG sources', () => {
    settings.render();

    const entries = container.querySelector('.manual-epg-sources')!;
    expect(entries.querySelector('.empty-hint')?.textContent)
      .toBe('No EPG sources added yet');

    click('#add-epg-source');
    expect(entries.querySelector('.empty-hint')).toBeNull();
    expect(entries.querySelectorAll('[data-manual-epg-source]')).toHaveLength(1);

    click('.remove-epg-source');
    expect(entries.querySelector('[data-manual-epg-source]')).toBeNull();
    expect(entries.querySelector('.empty-hint')?.textContent)
      .toBe('No EPG sources added yet');
  });

  it('adjusts and resets a manual EPG source offset with remote actions', () => {
    state.manualEpgSources = [{ url: 'http://host/epg.xml', playlistIds: [] }];
    settings.render();

    const plus = container.querySelector<HTMLElement>('[data-offset-delta="15"]')!;
    plus.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('select');
    expect(container.querySelector('.epg-offset-value')?.textContent?.trim()).toBe('+15 min');
    expect(container.querySelector('.epg-offset-preview')?.textContent).toContain('20:15');

    const value = container.querySelector<HTMLElement>('.epg-offset-value')!;
    value.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('select');
    expect(container.querySelector('.epg-offset-value')?.textContent?.trim()).toBe('0 min');

    value.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('left');
    expect(container.querySelector('.epg-offset-value')?.textContent?.trim()).toBe('0 min');

    const minus = container.querySelector<HTMLElement>('[data-offset-delta="-15"]')!;
    minus.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('select');
    click('#save-settings');
    expect(storageMock.setEpgOffsets).toHaveBeenCalledWith({
      'http://host/epg.xml': -15,
    });
    expect(onSave).toHaveBeenCalledWith('reload');
  });

  it('rebinds time correction when the manual XMLTV URL is edited', () => {
    state.manualEpgSources = [{ url: 'http://host/old.xml', playlistIds: [] }];
    state.epgOffsets = { 'http://host/old.xml': 30 };
    settings.render();

    const input = container.querySelector<HTMLInputElement>('.manual-epg-url')!;
    input.value = 'http://host/new.xml';
    input.dispatchEvent(new Event('input', { bubbles: true }));

    expect(container.querySelector<HTMLElement>('#epg-offset-source')?.dataset.value)
      .toBe('http://host/new.xml');
    expect(container.querySelector('.epg-offset-value')?.textContent?.trim()).toBe('0 min');
    click('[data-offset-delta="15"]');
    click('#save-settings');
    expect(storageMock.setEpgOffsets).toHaveBeenCalledWith({
      'http://host/new.xml': 15,
    });
  });

  it('orders manual EPG sources and binds each one to selected playlists', () => {
    state.playlists = [
      { id: 'p1', name: 'Alpha', url: 'http://host/a' },
      { id: 'p2', name: 'Bravo', url: 'http://host/b' },
    ];
    state.manualEpgSources = [
      { url: 'http://host/a.xml', playlistIds: ['p1'] },
      { url: 'http://host/b.xml', playlistIds: [] },
    ];
    settings.render();

    const rows = container.querySelectorAll<HTMLElement>('[data-manual-epg-source]');
    expect(rows).toHaveLength(2);
    expect(rows[0].querySelector('[data-scope-all]')?.textContent?.trim())
      .toBe('All playlists');
    expect(rows[0].querySelector('[data-playlist-id="p1"]')?.classList)
      .toContain('active');
    expect(rows[0].querySelector('[data-scope-all]')?.classList)
      .not.toContain('active');
    expect(rows[1].querySelector('[data-scope-all]')?.classList)
      .toContain('active');
    expect(rows[0].querySelector<HTMLButtonElement>('.move-epg-earlier')?.disabled)
      .toBe(true);
    expect(rows[0].querySelector('.move-epg-earlier')?.hasAttribute('data-focusable'))
      .toBe(false);
    expect(rows[1].querySelector<HTMLButtonElement>('.move-epg-later')?.disabled)
      .toBe(true);
    expect(rows[1].querySelector('.move-epg-later')?.hasAttribute('data-focusable'))
      .toBe(false);

    rows[1].querySelector<HTMLElement>('[data-playlist-id="p2"]')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    const moveEarlier = rows[1].querySelector<HTMLElement>('.move-epg-earlier')!;
    moveEarlier.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    moveEarlier.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    const reordered = container.querySelectorAll<HTMLElement>('[data-manual-epg-source]');
    expect(reordered[0].querySelector<HTMLButtonElement>('.move-epg-earlier')?.disabled)
      .toBe(true);
    expect(reordered[0].querySelector('.move-epg-earlier')?.hasAttribute('data-focusable'))
      .toBe(false);
    expect(reordered[0].querySelector('.move-epg-later')?.hasAttribute('data-focusable'))
      .toBe(true);
    expect(reordered[0].querySelector('.manual-epg-url')?.classList)
      .toContain('focused');
    click('#save-settings');

    expect(storageMock.setManualEpgSources).toHaveBeenCalledWith([
      { url: 'http://host/b.xml', playlistIds: ['p2'] },
      { url: 'http://host/a.xml', playlistIds: ['p1'] },
    ]);
    expect(onSave).toHaveBeenCalledWith('reload');
  });

  it('keeps manual EPG scopes synchronized with playlist edits', () => {
    state.playlists = [
      { id: 'p1', name: 'Alpha', url: 'http://host/a' },
    ];
    state.manualEpgSources = [
      { url: 'http://host/a.xml', playlistIds: ['p1'] },
    ];
    settings.render();

    click('#add-playlist');
    const addedPlaylist = Array.from(
      container.querySelectorAll<HTMLElement>(
        '#playlist-entries .settings-row:not(.playlist-header-row)',
      ),
    ).at(-1)!;
    const addedId = addedPlaylist.dataset.id!;
    const name = addedPlaylist.querySelector<HTMLInputElement>('.playlist-name')!;
    name.value = 'Bravo';
    name.dispatchEvent(new Event('input', { bubbles: true }));

    expect(container.querySelector(
      `[data-manual-epg-source] [data-playlist-id="${addedId}"]`,
    )?.textContent?.trim()).toBe('Bravo');

    const originalPlaylist = container.querySelector<HTMLElement>(
      '#playlist-entries .settings-row[data-id="p1"]',
    )!;
    originalPlaylist.querySelector<HTMLElement>('.remove-playlist')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));

    const source = container.querySelector<HTMLElement>('[data-manual-epg-source]')!;
    expect(source.querySelector('[data-playlist-id="p1"]')).toBeNull();
    expect(source.querySelector('[data-scope-all]')?.classList).toContain('active');

    click('#add-epg-source');
    const addedSource = Array.from(
      container.querySelectorAll<HTMLElement>('[data-manual-epg-source]'),
    ).at(-1)!;
    expect(addedSource.querySelector(`[data-playlist-id="${addedId}"]`)).not.toBeNull();
  });

  it('rejects duplicate manual EPG URLs before saving any settings', () => {
    state.manualEpgSources = [
      { url: 'http://host/a.xml', playlistIds: [] },
      { url: 'http://host/b.xml', playlistIds: [] },
    ];
    settings.render();
    const inputs = container.querySelectorAll<HTMLInputElement>('.manual-epg-url');
    inputs[1].value = inputs[0].value;

    click('#save-settings');

    expect(storageMock.setPlaylists).not.toHaveBeenCalled();
    expect(storageMock.setManualEpgSources).not.toHaveBeenCalled();
    expect(toastMock.showToast).toHaveBeenCalledWith(
      'Each EPG source must use a unique URL.',
    );
    expect(inputs[1].classList).toContain('focused');
  });

  it('does not assign a source to an ambiguous legacy channel key', () => {
    const first = {
      id: 'ch1',
      name: 'Alpha',
      logo: '',
      group: '',
      url: 'http://host/live?id=1',
      extras: null,
      playlistIds: ['p1'],
      catchup: '',
      catchupSource: '',
      catchupDays: 0,
    };
    const second = {
      ...first,
      id: 'ch2',
      name: 'Bravo',
      url: 'http://host/live?id=2',
      playlistIds: ['p2'],
    };
    PlaylistService.channels = [first, second];
    const sourceUrl = vi.spyOn(EpgService, 'getSourceUrl')
      .mockImplementation(channel =>
        channel === first ? 'http://host/a.xml' : 'http://host/b.xml');
    settings.render();

    click('#save-settings');

    const sourceMap = storageMock.migrateCatchupEpgOffsets.mock.calls[0][2];
    expect(sourceMap[channelKey(first)]).toBe('http://host/a.xml');
    expect(sourceMap[channelKey(second)]).toBe('http://host/b.xml');
    expect(sourceMap).not.toHaveProperty(legacyChannelKey(first));
    sourceUrl.mockRestore();
  });

  it('switches between discovered EPG sources without mixing their offsets', () => {
    state.playlists = [
      { id: 'p1', name: 'Alpha', url: 'http://host/a' },
      { id: 'p2', name: 'Bravo', url: 'http://host/b' },
    ];
    state.epgOffsets = { 'http://host/b.xml': 60 };
    PlaylistService.epgSources = [
      { url: 'http://host/a.xml', playlistIds: ['p1'], kind: 'm3u' },
      { url: 'http://host/b.xml', playlistIds: ['p2'], kind: 'm3u' },
    ];
    settings.render();

    click('#epg-offset-source [data-dropdown-trigger]');
    click('#epg-offset-source [data-dropdown-value="http://host/b.xml"]');

    expect(container.querySelector('#epg-offset-source .dropdown-current')?.textContent)
      .toBe('Bravo');
    expect(container.querySelector('.epg-offset-value')?.textContent?.trim()).toBe('+1 h');
  });

  it('uses XMLTV names and numbers unnamed EPG feeds from one playlist', () => {
    state.playlists = [{ id: 'p1', name: 'Alpha', url: 'http://host/a' }];
    PlaylistService.epgSources = [
      { url: 'http://host/a.xml', playlistIds: ['p1'], kind: 'm3u' },
      { url: 'http://host/b.xml', playlistIds: ['p1'], kind: 'm3u' },
      { url: 'http://host/c.xml', playlistIds: ['p1'], kind: 'm3u' },
    ];
    const sourceName = vi.spyOn(EpgService, 'getSourceName')
      .mockImplementation(url => url.endsWith('/a.xml') ? 'Guide Alpha' : null);

    settings.render();

    expect(Array.from(container.querySelectorAll('#epg-offset-source .dropdown-option'))
      .map(option => option.textContent?.trim()))
      .toEqual(['Guide Alpha', 'Alpha — EPG 1', 'Alpha — EPG 2']);
    sourceName.mockRestore();
  });

  it('qualifies duplicate XMLTV names with playlist names', () => {
    state.playlists = [
      { id: 'p1', name: 'Alpha', url: 'http://host/a' },
      { id: 'p2', name: 'Bravo', url: 'http://host/b' },
    ];
    PlaylistService.epgSources = [
      { url: 'http://host/a.xml', playlistIds: ['p1'], kind: 'm3u' },
      { url: 'http://host/b.xml', playlistIds: ['p2'], kind: 'm3u' },
    ];
    const sourceName = vi.spyOn(EpgService, 'getSourceName')
      .mockReturnValue('Shared Guide');

    settings.render();

    expect(Array.from(container.querySelectorAll('#epg-offset-source .dropdown-option'))
      .map(option => option.textContent?.trim()))
      .toEqual(['Shared Guide — Alpha', 'Shared Guide — Bravo']);
    sourceName.mockRestore();
  });

  it('shows total and per-category cache usage', async () => {
    settings.render();
    await vi.waitFor(() => {
      expect(container.querySelector('.cache-usage-total')?.textContent)
        .toContain('438 MiB');
    });
    expect(container.querySelector('.cache-usage-total')?.textContent).toContain('1.00 GiB');
    expect(container.querySelector('.cache-usage-ring-used')
      ?.getAttribute('stroke-dasharray')).toBe('42.8 100');
    expect(container.querySelector('.cache-usage-ring-used')
      ?.getAttribute('transform')).toBe('rotate(-90 60 60)');
    const breakdown = container.querySelector('.cache-usage-breakdown')!;
    expect(breakdown.previousElementSibling?.classList.contains('cache-usage-total')).toBe(true);
    expect(breakdown.children).toHaveLength(6);
    expect(breakdown.lastElementChild?.textContent).toBe('Search Index 3.00 MiB');
    expect(breakdown.textContent).toContain('286 MiB');
    expect(breakdown.textContent).toContain('92.0 MiB');
    expect(breakdown.textContent).toContain('Channel Health');
  });
});

describe('Settings theme picker', () => {
  beforeEach(() => settings.render());

  it('renders a swatch per registered theme with the saved theme active', () => {
    expect(container.querySelectorAll('.theme-swatch')).toHaveLength(15);
    expect(container.querySelector('.theme-swatch.active')!.getAttribute('data-theme-id')).toBe('midnight');
  });

  it('marks the saved theme active on open', () => {
    state.theme = 'plum-night';
    settings.render();
    const active = container.querySelectorAll('.theme-swatch.active');
    expect(active).toHaveLength(1);
    expect(active[0].getAttribute('data-theme-id')).toBe('plum-night');
  });

  it('selecting a swatch previews it and moves the active marker', () => {
    click('.theme-swatch[data-theme-id="arctic"]');
    expect(themeMock.previewTheme).toHaveBeenCalledWith('arctic');
    const active = container.querySelectorAll('.theme-swatch.active');
    expect(active).toHaveLength(1);
    expect(active[0].getAttribute('data-theme-id')).toBe('arctic');
  });

  it('previews on pointer hover and restores the selected theme when the pointer leaves', async () => {
    // Select Arctic (pending), then hover a different swatch and move the pointer off.
    click('.theme-swatch[data-theme-id="arctic"]');
    const amber = container.querySelector<HTMLElement>('.theme-swatch[data-theme-id="vintage-amber"]')!;
    amber.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    expect(themeMock.previewTheme).toHaveBeenLastCalledWith('vintage-amber');
    // Leaving to a non-swatch restores the selected (Arctic), not the saved (midnight).
    amber.dispatchEvent(new CustomEvent('nav:unhover', { bubbles: true }));
    await Promise.resolve();
    expect(themeMock.previewTheme).toHaveBeenLastCalledWith('arctic');
  });

  it('keeps previewing when the pointer moves between swatches', async () => {
    const arctic = container.querySelector<HTMLElement>('.theme-swatch[data-theme-id="arctic"]')!;
    const amber = container.querySelector<HTMLElement>('.theme-swatch[data-theme-id="vintage-amber"]')!;
    arctic.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    themeMock.previewTheme.mockClear();
    arctic.dispatchEvent(new CustomEvent('nav:unhover', { bubbles: true }));
    amber.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    await Promise.resolve();
    // Each theme change restyles the whole document, so swatch→swatch must
    // not restore the selected theme in between.
    expect(themeMock.previewTheme.mock.calls).toEqual([['vintage-amber']]);
  });

  it('persists the selected theme only on Save & Apply', () => {
    click('.theme-swatch[data-theme-id="vintage-amber"]');
    expect(storageMock.setTheme).not.toHaveBeenCalled();
    click('#save-settings');
    expect(storageMock.setTheme).toHaveBeenCalledWith('vintage-amber');
  });

  it('reflects the saved overlay style on the toggle', () => {
    state.overlayStyle = 'frosted';
    settings.render();
    expect(container.querySelector('#overlay-style .toggle-option.active')!.getAttribute('data-value')).toBe('frosted');
  });

  it('labels the theme swatches as a child setting', () => {
    settings.render();
    expect(container.querySelector('#settings-appearance .settings-item-title')?.textContent)
      .toBe('Theme');
  });

  it('renders preferred subtitles as a child setting', () => {
    settings.render();
    const item = container.querySelector('#os-pref-lang')?.closest('.settings-item');
    expect(item?.querySelector('.settings-item-title')?.textContent)
      .toBe('Preferred subtitle language');
    expect(item?.closest('.settings-row')).toBeNull();
  });

  it('persists the overlay style on Save & Apply', () => {
    click('#overlay-style .toggle-option[data-value="frosted"]');
    click('#save-settings');
    expect(storageMock.setOverlayStyle).toHaveBeenCalledWith('frosted');
  });

  it('reflects the saved text size on the dropdown', () => {
    state.textSize = '120';
    settings.render();
    const dd = container.querySelector('#text-size')!;
    expect(dd.getAttribute('data-value')).toBe('120');
    expect(dd.querySelector('.dropdown-current')!.textContent).toBe('120%');
  });

  it('offers every percentage step and marks 100% as the default', () => {
    settings.render();
    const labels = Array.from(container.querySelectorAll('#text-size .dropdown-option'))
      .map(o => o.getAttribute('data-dropdown-value'));
    expect(labels).toEqual(['80', '90', '100', '110', '120', '130', '140', '150']);
    expect(container.querySelector('#text-size .dropdown-option[data-dropdown-value="100"]')!.textContent)
      .toBe('100% (Default)');
  });

  it('previews the text size immediately and persists it on Save & Apply', () => {
    click('#text-size .dropdown-option[data-dropdown-value="130"]');
    expect(themeMock.applyTextSize).toHaveBeenCalledWith('130');
    expect(storageMock.setTextSize).not.toHaveBeenCalled();
    click('#save-settings');
    expect(storageMock.setTextSize).toHaveBeenCalledWith('130');
  });
});

describe('Settings editing', () => {
  beforeEach(() => settings.render());

  it('adds a playlist row and removes the empty hint', () => {
    click('#add-playlist');
    expect(container.querySelectorAll('#playlist-entries .settings-row:not(.playlist-header-row)')).toHaveLength(1);
    expect(container.querySelector('#playlist-entries .empty-hint')).toBeNull();
  });

  it('removes a playlist row', () => {
    state.playlists = [{ name: 'P1', url: 'http://a' }];
    settings.render();
    expect(container.querySelectorAll('#playlist-entries .settings-row:not(.playlist-header-row)')).toHaveLength(1);
    click('.remove-playlist');
    expect(container.querySelectorAll('#playlist-entries .settings-row:not(.playlist-header-row)')).toHaveLength(0);
  });

  it('keeps each survivor\'s name and stable id when a middle row is removed', () => {
    // Reproduces: add 5 with blank names, delete the 3rd, save. The 5th must
    // keep its "Playlist 5" name AND its original id — no positional renumber,
    // no re-id — so its tab/channels stay put.
    const urls = ['http://a', 'http://b', 'http://c', 'http://d', 'http://e'];
    for (let i = 0; i < 5; i++) {
      click('#add-playlist');
      const urlInputs = container.querySelectorAll<HTMLInputElement>('.playlist-url');
      urlInputs[urlInputs.length - 1].value = urls[i];
    }
    const rows = () => Array.from(container.querySelectorAll<HTMLElement>(
      '#playlist-entries .settings-row:not(.playlist-header-row)'));
    const idBefore = rows().map(r => r.dataset.id);
    expect(rows().map(r => r.querySelector<HTMLInputElement>('.playlist-name')!.value))
      .toEqual(['Playlist 1', 'Playlist 2', 'Playlist 3', 'Playlist 4', 'Playlist 5']);

    container.querySelectorAll<HTMLElement>('.remove-playlist')[2]
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    click('#save-settings');

    const saved = storageMock.setPlaylists.mock.calls.at(-1)![0] as { id: string; name: string }[];
    expect(saved.map(p => p.name)).toEqual(['Playlist 1', 'Playlist 2', 'Playlist 4', 'Playlist 5']);
    expect(saved.map(p => p.id)).toEqual([idBefore[0], idBefore[1], idBefore[3], idBefore[4]]);
  });

  it('removes the row whose button was clicked, even after edits churn the row order', () => {
    // Regression: removal used to key off a positional data-index that went
    // stale/duplicate after an add-following-a-remove, so clicking one row's
    // Remove could delete a different row. It now deletes the row the button
    // sits in (closest), independent of ordering.
    const addRow = (name: string) => {
      click('#add-playlist');
      const last = Array.from(container.querySelectorAll<HTMLElement>(
        '#playlist-entries .settings-row:not(.playlist-header-row)')).at(-1)!;
      last.querySelector<HTMLInputElement>('.playlist-name')!.value = name;
      last.querySelector<HTMLInputElement>('.playlist-url')!.value = 'http://' + name;
    };
    const rowNames = () =>
      Array.from(container.querySelectorAll<HTMLInputElement>('.playlist-name')).map(n => n.value);
    const removeByName = (name: string) =>
      Array.from(container.querySelectorAll<HTMLElement>('.settings-row'))
        .find(r => r.querySelector<HTMLInputElement>('.playlist-name')?.value === name)!
        .querySelector<HTMLElement>('.remove-playlist')!
        .dispatchEvent(new MouseEvent('click', { bubbles: true }));

    addRow('A'); addRow('B'); addRow('C');
    removeByName('B');   // churn the middle
    addRow('D');         // re-add: under the old scheme D reused C's stale index
    expect(rowNames()).toEqual(['A', 'C', 'D']);

    removeByName('C');   // the old positional logic deleted D here instead
    expect(rowNames()).toEqual(['A', 'D']);
  });

  it("seeds the next-add name past the highest existing 'Playlist N'", () => {
    const urls = ['http://a', 'http://b', 'http://c', 'http://d'];
    for (let i = 0; i < 4; i++) {
      click('#add-playlist');
      container.querySelectorAll<HTMLInputElement>('.playlist-url')[i].value = urls[i];
    }
    container.querySelectorAll<HTMLElement>('.remove-playlist')[2] // remove 'Playlist 3'
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    click('#add-playlist');
    const names = Array.from(container.querySelectorAll<HTMLInputElement>('.playlist-name')).map(n => n.value);
    expect(names).toEqual(['Playlist 1', 'Playlist 2', 'Playlist 4', 'Playlist 5']);
  });

  it('shows Name/URL labels only once as column headers, not on every row', () => {
    state.playlists = [
      { name: 'P1', url: 'http://a' },
      { name: 'P2', url: 'http://b' },
      { name: 'P3', url: 'http://c' },
    ];
    settings.render();
    // Exactly two labels in #playlist-entries: one "Name", one "URL".
    const labels = Array.from(container.querySelectorAll<HTMLLabelElement>('#playlist-entries label'))
      .map((l) => l.textContent?.trim());
    expect(labels).toEqual(['Name', 'URL']);
    // The data rows themselves contain no labels (just inputs + Remove button).
    const dataRows = container.querySelectorAll('#playlist-entries .settings-row:not(.playlist-header-row)');
    for (const row of dataRows) {
      expect(row.querySelectorAll('label')).toHaveLength(0);
    }
  });

  it('removing the last playlist row also removes the column-header row', () => {
    state.playlists = [{ name: 'P1', url: 'http://a' }];
    settings.render();
    expect(container.querySelector('#playlist-entries .playlist-header-row')).not.toBeNull();
    click('.remove-playlist');
    expect(container.querySelector('#playlist-entries .playlist-header-row')).toBeNull();
    expect(container.querySelector('#playlist-entries .empty-hint')?.textContent).toBe('No playlists added yet');
  });

  it('add-playlist on an empty list inserts the header row first', () => {
    expect(container.querySelector('#playlist-entries .playlist-header-row')).toBeNull();
    click('#add-playlist');
    expect(container.querySelector('#playlist-entries .playlist-header-row')).not.toBeNull();
    expect(container.querySelectorAll('#playlist-entries .settings-row:not(.playlist-header-row)')).toHaveLength(1);
  });

  it('selecting On activates auto-play', () => {
    const activeVal = () => container.querySelector('#auto-play .toggle-option.active')!.getAttribute('data-value');
    expect(activeVal()).toBe('off');
    click('#auto-play [data-value="on"]');
    expect(activeVal()).toBe('on');
  });

  it('explains the cache scope and requires confirmation before clearing', async () => {
    click('#clear-cache');
    expect(document.querySelector('.confirmation-title')?.textContent).toBe('Clear cache?');
    expect(document.querySelector('.confirmation-message')?.textContent)
      .toContain('channel health results');
    expect(document.querySelector('.confirmation-message')?.textContent)
      .toContain('Accounts, settings, favorites, and viewing history are kept.');
    expect(cacheMock.clearAllCachedData).not.toHaveBeenCalled();

    settings.handleAction('left');
    settings.handleAction('select');

    await vi.waitFor(() => {
      expect(cacheMock.clearAllCachedData).toHaveBeenCalled();
      expect(healthMock.reset).toHaveBeenCalled();
      expect(onChannelsChanged).toHaveBeenCalled();
      expect(toastMock.showToast).toHaveBeenCalledWith('Cache cleared');
    });
  });

  it('waits for an active health check to stop before clearing cache', async () => {
    PlaylistService.allChannels = [{
      id: 'ch1',
      name: 'Alpha',
      logo: '',
      group: '',
      url: 'http://host/a',
      extras: null,
      playlistIds: [],
      catchup: '',
      catchupSource: '',
      catchupDays: 0,
    }];
    let signal: AbortSignal | undefined;
    let finish: (() => void) | null = null;
    healthMock.checkAll.mockImplementationOnce(async (_channels, options) => {
      signal = options.signal;
      await new Promise<void>(resolve => { finish = resolve; });
      return {
        total: 1,
        unknown: 1,
        healthy: 0,
        suspect: 0,
        unavailable: 0,
      };
    });
    settings.render();
    click('#check-channel-health');
    await vi.waitFor(() => expect(signal).toBeDefined());

    click('#clear-cache');
    settings.handleAction('left');
    settings.handleAction('select');

    await vi.waitFor(() => expect(signal?.aborted).toBe(true));
    expect(cacheMock.clearAllCachedData).not.toHaveBeenCalled();
    finish?.();
    await vi.waitFor(() => expect(cacheMock.clearAllCachedData).toHaveBeenCalled());
  });

  it('requires confirmation before requesting a full app reset', () => {
    click('#reset-app');
    expect(document.querySelector('.confirmation-title')?.textContent).toBe('Reset the app?');
    expect(onSave).not.toHaveBeenCalledWith('reset');

    settings.handleAction('left');
    settings.handleAction('select');

    expect(onSave).toHaveBeenCalledWith('reset');
  });

  it('reports a reset failure instead of leaving an unhandled rejection', async () => {
    onSave.mockRejectedValueOnce(new Error('clear failed'));
    click('#reset-app');

    settings.handleAction('left');
    settings.handleAction('select');

    await vi.waitFor(() => {
      expect(toastMock.showToast).toHaveBeenCalledWith(
        'Reset could not be completed. Restart the app and try again.',
      );
    });
  });

  it('cancel discards; refresh reloads', () => {
    click('#cancel-settings');
    expect(onSave).toHaveBeenLastCalledWith('cancel');
    click('#refresh-data');
    expect(onSave).toHaveBeenLastCalledWith('reload');
  });
});

describe('Settings Recently Watched clearing', () => {
  beforeEach(() => settings.render());

  it('groups the scope explanation and clear action in one setting', () => {
    const action = container.querySelector('#settings-data .settings-item--action');
    expect(action?.textContent).toContain('Recently Watched');
    expect(action?.textContent).toContain('Clear recent live channels and catch-up progress');
    expect(action?.querySelector('#clear-recently-watched')).not.toBeNull();
    expect(Array.from(action?.children ?? []).map(child => child.className)).toEqual([
      'settings-item-title',
      'btn btn-danger',
      'settings-item-hint',
    ]);
  });

  it('places maintenance actions after history settings', () => {
    const section = container.querySelector('#settings-data .settings-section')!;
    const recent = section.querySelector('.settings-item--action')!;
    const maintenance = section.querySelector('.settings-maintenance')!;
    expect(recent.compareDocumentPosition(maintenance) & Node.DOCUMENT_POSITION_FOLLOWING)
      .toBeTruthy();
  });

  describe('Settings Watchlist clearing', () => {
    beforeEach(() => {
      state.playlists = [
        {
          id: 'x1',
          name: 'Account Alpha',
          url: 'http://host',
          source: 'xtream',
          xtream: { username: 'u', password: 'p' },
        },
        {
          id: 'x2',
          name: 'Account Bravo',
          url: 'http://host',
          source: 'xtream',
          xtream: { username: 'u2', password: 'p2' },
        },
      ];
      storageMock.getSelectedXtreamAccountId.mockReturnValue('x2');
      settings.render();
    });

    it('hides both collection clear settings without an enabled Xtream account', () => {
      const collections = (): Element[] => ['#clear-continue-watching', '#clear-watchlist']
        .map(id => container.querySelector(id)).filter((el): el is Element => !!el);
      expect(collections()).toHaveLength(2);

      state.playlists = [{ id: 'p1', name: 'P1', url: 'http://host/a', source: 'url' }];
      settings.render();
      expect(collections()).toEqual([]);

      state.playlists = [{
        id: 'x1', name: 'Account Alpha', url: 'http://host', source: 'xtream', enabled: false,
        xtream: { username: 'u', password: 'p' },
      }];
      settings.render();
      expect(collections()).toEqual([]);
    });

    it('shows the selected account in the Watchlist clear setting', () => {
      const action = container.querySelector('#clear-watchlist')?.closest('.settings-item--action');
      expect(action?.textContent).toContain('Watchlist');
      expect(action?.textContent).toContain('Account Bravo');
    });

    it('shows counts for the selected account in both collection settings', () => {
      storageMock.getResumeList.mockReturnValueOnce([{}, {}, {}]);
      storageMock.getWatchlist.mockReturnValueOnce([{}, {}]).mockReturnValueOnce([{}]);
      settings.render();
      const resume = container.querySelector('#clear-continue-watching')?.closest('.settings-item--action');
      const watchlist = container.querySelector('#clear-watchlist')?.closest('.settings-item--action');
      expect(resume?.textContent).toContain('Account Bravo');
      expect(resume?.textContent).toContain('Clear saved playback progress for movies and series in "Account Bravo" (3).');
      expect(resume?.textContent).toContain('(3)');
      expect(watchlist?.textContent).toContain('(3)');
      expect(storageMock.getResumeList).toHaveBeenLastCalledWith('x2');
      expect(storageMock.getWatchlist).toHaveBeenCalledWith('x2', 'vod');
      expect(storageMock.getWatchlist).toHaveBeenCalledWith('x2', 'series');
    });

    it('omits only concealed collection counts and retains account-wide clearing', () => {
      const concealed = vi.spyOn(ParentalControlService, 'isConcealed')
        .mockImplementation(request => request.target.kind === 'vod-item'
          && request.target.itemId === 'hidden1');
      const hiddenResume = {
        accountId: 'x2', kind: 'vod', itemId: 'hidden1', name: 'Title 1', poster: '',
        ext: 'mp4', position: 100, duration: 600, updatedAt: 1,
      };
      const hiddenWatchlist = {
        accountId: 'x2', kind: 'vod', itemId: 'hidden1', name: 'Title 1', poster: '',
        categoryId: '1', addedAt: 1,
      };
      try {
        storageMock.getResumeList.mockReturnValue([hiddenResume]);
        storageMock.getWatchlist.mockImplementation((_accountId, kind) => kind === 'vod' ? [hiddenWatchlist] : []);
        settings.render();
        const resumeHint = () => container.querySelector('#continue-watching-count-hint')?.textContent;
        const watchlistHint = () => container.querySelector('#watchlist-count-hint')?.textContent;
        expect(resumeHint()).toContain('Account Bravo');
        expect(resumeHint()).toContain('Clear saved playback progress for movies and series in "Account Bravo".');
        expect(watchlistHint()).toContain('Account Bravo');
        expect(resumeHint()).not.toMatch(/\(\d+\)/);
        expect(watchlistHint()).not.toMatch(/\(\d+\)/);

        storageMock.getResumeList.mockReturnValue([]);
        click('#clear-continue-watching');
        settings.handleAction('left');
        settings.handleAction('select');
        expect(storageMock.clearResumeList).toHaveBeenCalledExactlyOnceWith('x2');
        expect(resumeHint()).toContain('(0)');
        expect(watchlistHint()).not.toMatch(/\(\d+\)/);

        click('#clear-watchlist');
        settings.handleAction('left');
        settings.handleAction('select');
        expect(storageMock.clearWatchlist).toHaveBeenCalledExactlyOnceWith('x2');
      } finally {
        concealed.mockRestore();
        storageMock.getResumeList.mockReturnValue([]);
        storageMock.getWatchlist.mockReturnValue([]);
      }
    });

    it('confirms clearing movie and episode progress for only the selected account', () => {
      click('#clear-continue-watching');
      expect(document.querySelector('.confirmation-title')?.textContent).toBe('Clear Continue Watching?');
      expect(document.querySelector('.confirmation-message')?.textContent).toContain('Account Bravo');
      expect(document.querySelector('.confirmation-message')?.textContent).toBe(
        'Clear all saved playback progress for movies and series in "Account Bravo"? Watchlist is not affected.',
      );
      expect(storageMock.clearResumeList).not.toHaveBeenCalled();
      settings.handleAction('left');
      settings.handleAction('select');
      expect(storageMock.clearResumeList).toHaveBeenCalledExactlyOnceWith('x2');
      expect(storageMock.clearWatchlist).not.toHaveBeenCalled();
      expect(toastMock.showToast).toHaveBeenCalledWith('Continue Watching cleared for "Account Bravo"');
      expect(container.querySelector('#continue-watching-count-hint')?.textContent).toContain('(0)');
    });

    it('requires confirmation and clears only the selected account', () => {
      click('#clear-watchlist');
      expect(document.querySelector('.confirmation-title')?.textContent).toBe('Clear Watchlist?');
      expect(document.querySelector('.confirmation-message')?.textContent).toContain('Account Bravo');
      expect(storageMock.clearWatchlist).not.toHaveBeenCalled();

      settings.handleAction('left');
      settings.handleAction('select');

      expect(storageMock.clearWatchlist).toHaveBeenCalledWith('x2');
      expect(toastMock.showToast).toHaveBeenCalledWith('Watchlist cleared for "Account Bravo"');
    });
  });

  it('requires confirmation before clearing Recently Watched', () => {
    click('#clear-recently-watched');
    expect(settings.isPromptVisible).toBe(true);
    expect(document.querySelector('.confirmation-title')?.textContent).toBe('Clear Recently Watched?');
    expect(storageMock.clearRecentlyWatched).not.toHaveBeenCalled();

    settings.handleAction('left');
    settings.handleAction('select');

    expect(storageMock.clearRecentlyWatched).toHaveBeenCalledTimes(1);
    expect(toastMock.showToast).toHaveBeenCalledWith('Recently Watched cleared');
    expect(settings.isPromptVisible).toBe(false);
  });

  it('notifies playback after resetting channel customization', () => {
    settings.render();
    click('#reset-customization');
    settings.handleAction('left');
    settings.handleAction('select');

    expect(onChannelsChanged).toHaveBeenCalledTimes(1);
  });

  it('notifies playback when changing hidden-channel visibility', () => {
    state.showHidden = true;
    settings.render();
    click('#show-hidden [data-value="off"]');
    click('#edit-channel-list');

    expect(state.showHidden).toBe(false);
    expect(onChannelsChanged).toHaveBeenCalledTimes(1);
  });

  it('cancels without clearing', () => {
    click('#clear-recently-watched');
    settings.handleAction('back');
    expect(storageMock.clearRecentlyWatched).not.toHaveBeenCalled();
    expect(settings.isPromptVisible).toBe(false);
  });
});

describe('Settings.save', () => {
  beforeEach(() => {
    state.playlists = [{ name: '', url: '' }, { name: '', url: '' }];
    settings.render();
  });

  it('defaults live preview to Off under Playback with its help text', () => {
    const item = container.querySelector('#live-preview-setting')!.closest('.settings-item')!;
    expect(item.closest('[data-settings-category]')?.getAttribute('data-settings-category'))
      .toBe('playback');
    expect(item.querySelector('.settings-item-title')?.textContent).toBe('Live preview');
    expect(item.querySelector('.settings-item-hint')?.textContent)
      .toBe('Watch live channels in a small window while you browse.');
    expect(item.querySelector('.toggle-option.active')?.getAttribute('data-value')).toBe('off');
    expect(storageMock.setLivePreview).not.toHaveBeenCalled();
  });

  it.each([false, true])('saves live preview from %s without reloading sources', (enabled) => {
    state.playlists = [];
    state.livePreview = enabled;
    settings.render();
    const activeValue = () => container.querySelector('#live-preview-setting .toggle-option.active')
      ?.getAttribute('data-value');
    expect(activeValue()).toBe(enabled ? 'on' : 'off');

    click(`#live-preview-setting [data-value="${enabled ? 'off' : 'on'}"]`);
    expect(activeValue()).toBe(enabled ? 'off' : 'on');
    expect(state.livePreview).toBe(enabled);
    expect(storageMock.setLivePreview).not.toHaveBeenCalled();

    click('#save-settings');
    expect(storageMock.setLivePreview).toHaveBeenCalledExactlyOnceWith(!enabled);
    expect(state.livePreview).toBe(!enabled);
    expect(onSave).toHaveBeenCalledWith('apply');
    expect(storageMock.setAutoPlay).toHaveBeenCalledWith(false);
    settings.render();
    expect(activeValue()).toBe(enabled ? 'off' : 'on');
  });

  it.each([false, true])('discards an unsaved live preview change from %s on Cancel', (enabled) => {
    state.livePreview = enabled;
    settings.render();
    click(`#live-preview-setting [data-value="${enabled ? 'off' : 'on'}"]`);
    click('#cancel-settings');
    expect(onSave).toHaveBeenCalledWith('cancel');
    expect(storageMock.setLivePreview).not.toHaveBeenCalled();
    expect(state.livePreview).toBe(enabled);
    settings.render();
    expect(container.querySelector('#live-preview-setting .toggle-option.active')?.getAttribute('data-value'))
      .toBe(enabled ? 'on' : 'off');
  });

  it('persists trimmed playlists, EPG and auto-play, then reloads', () => {
    const names = container.querySelectorAll<HTMLInputElement>('.playlist-name');
    const urls = container.querySelectorAll<HTMLInputElement>('.playlist-url');
    names[0].value = 'My';
    urls[0].value = '  http://x  ';
    names[1].value = 'Unnamed';
    urls[1].value = '   '; // blank URL -> dropped
    click('#add-epg-source');
    container.querySelector<HTMLInputElement>('.manual-epg-url')!.value = ' http://epg ';
    click('#auto-play [data-value="on"]');

    click('#save-settings');

    expect(storageMock.setPlaylists).toHaveBeenCalledWith([{ id: expect.any(String), name: 'My', url: 'http://x', source: 'url' }]);
    expect(storageMock.setManualEpgSources).toHaveBeenCalledWith([
      { url: 'http://epg', playlistIds: [] },
    ]);
    expect(storageMock.setAutoPlay).toHaveBeenCalledWith(true);
    expect(onSave).toHaveBeenCalledWith('reload'); // playlist + EPG changed
  });

  it("reloads when a playlist is re-id'd (same name+url, new id)", () => {
    // Delete + re-add of the same name/url gives the row a fresh id; the
    // signature must notice the id changed (else cache keeps the old id).
    state.playlists = [{ id: 'a', name: 'P', url: 'http://p' }];
    settings.render();
    container.querySelector<HTMLElement>(
      '#playlist-entries .settings-row:not(.playlist-header-row)')!.dataset.id = 'b';
    click('#save-settings');
    expect(onSave).toHaveBeenCalledWith('reload');
  });

  it('applies a display-only change without a full reload', () => {
    state.playlists = [{ id: 'p1', name: 'P', url: 'http://p' }]; // unchanged by the form
    settings.render();
    click('#tz-mode [data-value="feed"]'); // only the time zone changes
    click('#save-settings');
    expect(storageMock.setTzMode).toHaveBeenCalledWith('feed');
    expect(onSave).toHaveBeenCalledWith('apply'); // no re-fetch
  });

  it('persists the selected app language as a display-only change', () => {
    state.playlists = [{ id: 'p1', name: 'P', url: 'http://p' }];
    settings.render();
    click('#app-language [data-dropdown-trigger]');
    click('#app-language [data-dropdown-value="zh-CN"]');
    click('#save-settings');
    expect(storageMock.setLocalePreference).toHaveBeenCalledWith('zh-CN');
    expect(onSave).toHaveBeenCalledWith('apply');
  });

  it('saves reconnect attempts without forcing a full data reload', () => {
    state.playlists = [];
    settings.render();

    click('#live-reconnect-attempts [data-dropdown-value="5"]');
    click('#save-settings');

    expect(storageMock.setLiveReconnectAttempts).toHaveBeenCalledWith(5);
    expect(onSave).toHaveBeenCalledWith('apply');
  });

  it('saves playlist and guide refresh intervals without forcing a data reload', () => {
    settings.render();

    click('#playlist-refresh-interval [data-dropdown-value="12"]');
    click('#epg-refresh-interval [data-dropdown-value="0"]');
    state.playlists = [];
    click('#save-settings');

    expect(storageMock.setPlaylistRefreshIntervalHours).toHaveBeenCalledWith(12);
    expect(storageMock.setEpgRefreshIntervalHours).toHaveBeenCalledWith(0);
    expect(storageMock.setXtreamCatalogRefreshIntervalHours).not.toHaveBeenCalled();
    expect(onSave).toHaveBeenCalledWith('apply');
  });

  it('saves the Xtream catalog refresh interval when the control is available', () => {
    state.playlists = [{
      id: 'x1',
      name: 'Account',
      url: 'http://host',
      source: 'xtream',
      xtream: { username: 'u', password: 'p' },
    }];
    settings.render();

    click('#xtream-catalog-refresh-interval [data-dropdown-value="12"]');
    click('#save-settings');

    expect(storageMock.setXtreamCatalogRefreshIntervalHours).toHaveBeenCalledWith(12);
  });

  it('renders the Settings title in Simplified Chinese', () => {
    setLocale('zh-CN');
    settings.render();
    expect(container.querySelector('.settings-title')?.textContent).toBe('设置');
    expect(container.querySelector('#app-language')?.closest('.settings-section')
      ?.querySelector('h3')?.textContent).toBe('语言 / Language');
    expect(container.querySelector('#app-language .dropdown-current')?.textContent).toBe('跟随系统');
  });

  it('defaults a missing name to "Playlist N"', () => {
    const urls = container.querySelectorAll<HTMLInputElement>('.playlist-url');
    urls[0].value = 'http://only';
    click('#save-settings');
    expect(storageMock.setPlaylists).toHaveBeenCalledWith([{ id: expect.any(String), name: 'Playlist 1', url: 'http://only', source: 'url' }]);
  });

  it('selecting the Feed option persists the feed mode', () => {
    const activeTz = () => container.querySelector('#tz-mode .toggle-option.active')!.getAttribute('data-value');
    expect(activeTz()).toBe('device'); // default
    click('#tz-mode [data-value="feed"]');
    expect(activeTz()).toBe('feed');
    click('#save-settings');
    expect(storageMock.setTzMode).toHaveBeenCalledWith('feed');
  });

  it('selecting Active persists the channel cycle mode, defaulting to Global', () => {
    const activeMode = () => container.querySelector('#channel-cycle-mode .toggle-option.active')!.getAttribute('data-value');
    expect(activeMode()).toBe('global'); // default — preserves pre-scoping behavior
    click('#channel-cycle-mode [data-value="active"]');
    expect(activeMode()).toBe('active');
    click('#save-settings');
    expect(storageMock.setChannelCycleMode).toHaveBeenCalledWith('active');
  });

  it('saves online subtitle credentials', () => {
    settings.render();
    (container.querySelector('#subdl-key') as HTMLInputElement).value = 'SK';
    (container.querySelector('#os-key') as HTMLInputElement).value = 'OK';
    (container.querySelector('#os-user') as HTMLInputElement).value = 'u';
    (container.querySelector('#os-pass') as HTMLInputElement).value = 'p';
    click('#os-pref-lang [data-dropdown-value="zh-CN"]');
    click('#save-settings');
    const cfg = storageMock.getOnlineSubtitleConfig();
    expect(cfg.subdl.apiKey).toBe('SK');
    expect(cfg.opensubtitles).toMatchObject({ apiKey: 'OK', username: 'u', password: 'p' });
    expect(cfg.preferredLanguage).toBe('zh-CN');
  });

  it('saves the Assrt token', () => {
    settings.render();
    (container.querySelector('#assrt-key') as HTMLInputElement).value = 'AZ';
    click('#save-settings');
    expect(storageMock.getOnlineSubtitleConfig().assrt.apiKey).toBe('AZ');
  });
});

describe('Settings.handleAction', () => {
  const hover = (el: Element) => el.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
  const unhover = (el: Element) => el.dispatchEvent(new CustomEvent('nav:unhover', { bubbles: true }));
  const rings = () => Array.from(container.querySelectorAll('.focused'));
  const key = (el: Element, init: KeyboardEventInit) =>
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, ...init }));

  it('tints the Advanced row of the focused control only', () => {
    settings.render();
    const trigger = container.querySelector('#number-entry-osd-timeout .dropdown-trigger')!;
    hover(trigger);
    expect(rings()).toEqual([trigger]);
    expect(trigger.closest('.settings-advanced-row')?.classList.contains('is-current')).toBe(true);
    unhover(trigger);
    expect(rings()).toEqual([]);
    expect(container.querySelector('.settings-advanced-row.is-current')).toBeNull();
  });

  it('only shows a field the pointer left on the next OK, without taking the caret', () => {
    settings.render();
    const field = container.querySelector<HTMLInputElement>('#subdl-key')!;
    hover(field);
    unhover(field);
    expect(rings()).toEqual([]);

    expect(settings.handleAction('select')).toBe(true);
    expect(rings()).toEqual([field]);
    expect(document.activeElement).not.toBe(field);

    settings.handleAction('select');
    expect(document.activeElement).toBe(field);
  });

  it('keeps the ring on a field with the caret and hands it to the hovered control after', () => {
    settings.render();
    const field = container.querySelector<HTMLInputElement>('#subdl-key')!;
    const other = container.querySelector<HTMLInputElement>('#assrt-key')!;
    hover(field);
    settings.handleAction('select');
    expect(document.activeElement).toBe(field);

    hover(other);
    expect(rings()).toEqual([field]);
    unhover(field);
    expect(rings()).toEqual([field]);

    field.blur();
    expect(rings()).toEqual([other]);
  });

  it('lets Back and Up take the caret out of a field', () => {
    settings.render();
    const field = container.querySelector<HTMLInputElement>('#assrt-key')!;
    hover(field);
    settings.handleAction('select');
    expect(document.activeElement).toBe(field);

    key(field, { key: 'Escape', keyCode: 27 });
    expect(document.activeElement).not.toBe(field);
    expect(rings()).toEqual([field]);

    settings.handleAction('select');
    key(field, { key: 'ArrowUp', keyCode: 38 });
    expect(document.activeElement).not.toBe(field);
    expect(rings()).toHaveLength(1);
  });

  it('takes the caret out of a field on a remote arrow that names only its key code', () => {
    settings.render();
    const field = container.querySelector<HTMLInputElement>('#assrt-key')!;
    hover(field);
    settings.handleAction('select');
    expect(document.activeElement).toBe(field);

    expect(key(field, { keyCode: CONFIG.KEYS.UP })).toBe(false);
    expect(document.activeElement).not.toBe(field);
    expect(rings()).toHaveLength(1);

    hover(field);
    settings.handleAction('select');
    expect(document.activeElement).toBe(field);
    expect(key(field, { keyCode: CONFIG.KEYS.DOWN })).toBe(false);
    expect(document.activeElement).not.toBe(field);
    expect(rings()).toHaveLength(1);
  });

  it('takes the caret out of a field when something above Settings takes the keys', () => {
    settings.render();
    const field = container.querySelector<HTMLInputElement>('#subdl-key')!;
    hover(field);
    settings.handleAction('select');
    const elsewhere = Focus.register({ id: 'test.elsewhere', root: document.body });
    Focus.push(elsewhere);
    Focus.flush();
    expect(document.activeElement).not.toBe(field);
    Focus.pop(elsewhere);
  });

  it('does not preview the hovered swatch when Settings gives the keys away from a field', () => {
    settings.render();
    const field = container.querySelector<HTMLInputElement>('#subdl-key')!;
    const swatch = container.querySelector<HTMLElement>('.theme-swatch[data-theme-id="arctic"]')!;
    hover(field);
    settings.handleAction('select');
    const before = settings.focusScope.focusKey;
    hover(swatch);
    themeMock.previewTheme.mockClear();
    const elsewhere = Focus.register({ id: 'test.elsewhere', root: document.body });
    Focus.push(elsewhere);
    Focus.flush();
    expect(document.activeElement).not.toBe(field);
    expect(themeMock.previewTheme).not.toHaveBeenCalledWith('arctic');
    expect(settings.focusScope.focusKey).toBe(before);
    Focus.pop(elsewhere);
  });

  it('leaves Up from the first category to the host', () => {
    settings.render();
    const general = container.querySelector('[data-settings-target="general"]');
    expect(general?.classList.contains('focused')).toBe(true);
    expect(settings.handleAction('up')).toBe(false);
    expect(general?.classList.contains('focused')).toBe(true);
  });

  it('returns to the trigger of a dropdown that closed while Settings was away', () => {
    settings.render();
    click('#app-language [data-dropdown-trigger]');
    settings.handleAction('down');
    const option = container.querySelector('#app-language .dropdown-option.focused');
    expect(option).not.toBeNull();

    settings.render();
    const trigger = container.querySelector('#app-language .dropdown-trigger');
    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(false);
    expect(rings()).toEqual([trigger]);
    settings.handleAction('select');
    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(true);
  });

  it('marks the category of the control it returns to', () => {
    settings.render();
    const control = container.querySelector<HTMLElement>('#settings-guide [data-focusable]')!;
    hover(control);
    expect(rings()).toEqual([control]);

    settings.render();
    expect(rings()).toEqual([container.querySelector('#settings-guide [data-focusable]')]);
    expect(Array.from(container.querySelectorAll<HTMLElement>('.settings-nav-item.active'))
      .map(item => item.dataset.settingsTarget)).toEqual(['guide']);
  });

  it('returns to the same playlist option after a playlist is added before it', () => {
    state.playlists = [
      { id: 'p1', name: 'Alpha', url: 'http://host/a' },
      { id: 'p2', name: 'Bravo', url: 'http://host/b' },
    ];
    state.manualEpgSources = [{ url: 'http://host/a.xml', playlistIds: [] }];
    settings.render();
    hover(container.querySelector('[data-manual-epg-source] [data-playlist-id="p2"]')!);

    state.playlists = [{ id: 'p0', name: 'Charlie', url: 'http://host/c' }, ...state.playlists];
    settings.render();
    expect(rings().map(el => (el as HTMLElement).dataset.playlistId)).toEqual(['p2']);
  });

  it('returns to the same EPG source button after another source is added', () => {
    state.manualEpgSources = [
      { url: 'http://host/a.xml', playlistIds: [] },
      { url: 'http://host/b.xml', playlistIds: [] },
    ];
    settings.render();
    const second = () => container.querySelectorAll('[data-manual-epg-source]')[1];
    hover(second().querySelector('.remove-epg-source')!);

    state.manualEpgSources = [...state.manualEpgSources, { url: 'http://host/c.xml', playlistIds: [] }];
    settings.render();
    expect(rings()).toEqual([second().querySelector('.remove-epg-source')]);
  });

  it('keeps Up inside an open dropdown', () => {
    settings.render();
    click('#app-language [data-dropdown-trigger]');
    expect(settings.handleAction('up')).toBe(true);
    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(true);
  });

  it('dismisses an open dropdown and restores focus to its trigger', () => {
    settings.render();
    click('#app-language [data-dropdown-trigger]');
    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(true);

    expect(settings.dismissDropdown()).toBe(true);
    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(false);
    expect(container.querySelector('#app-language .dropdown-trigger')?.classList.contains('focused'))
      .toBe(true);
    expect(settings.dismissDropdown()).toBe(false);
  });

  it('closes an open dropdown when clicking elsewhere in Settings', () => {
    settings.render();
    click('#app-language [data-dropdown-trigger]');
    click('.settings-title');
    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(false);
  });

  it('closes an open dropdown before moving left to the category sidebar', () => {
    settings.render();
    click('#app-language [data-dropdown-trigger]');

    settings.handleAction('left');

    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(false);
    expect(container.querySelector('[data-settings-target="general"]')
      ?.classList.contains('focused')).toBe(true);
    expect(settings.dismissDropdown()).toBe(false);
  });

  it('keeps remote actions in an open dropdown after pointer focus escapes', () => {
    settings.render();
    click('#app-language [data-dropdown-trigger]');
    const save = container.querySelector<HTMLElement>('#save-settings')!;
    save.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));

    settings.handleAction('down');

    expect(container.querySelector('#app-language')?.classList.contains('open')).toBe(true);
    expect(container.querySelector('#app-language .dropdown-option.focused')).not.toBeNull();
    expect(storageMock.setPlaylists).not.toHaveBeenCalled();

    save.dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('select');

    expect(container.querySelector('#app-language .dropdown-option.active')
      ?.classList.contains('focused')).toBe(true);
    expect(storageMock.setPlaylists).not.toHaveBeenCalled();
  });

  it('select activates the focused control (remote OK)', () => {
    state.playlists = [{ name: 'P1', url: 'http://a' }];
    settings.render();
    container.querySelector<HTMLElement>('#save-settings')!
      .dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('select');
    expect(storageMock.setPlaylists).toHaveBeenCalled();
  });

  it('moves right from a category to its first control', () => {
    settings.render();
    const appearance = container.querySelector<HTMLElement>(
      '[data-settings-target="appearance"]',
    )!;
    appearance
      .dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('right');
    expect(container.querySelector('.theme-swatch.focused')).not.toBeNull();
    container.querySelector('.settings-scroll')!
      .dispatchEvent(new Event('scroll', { bubbles: true }));
    expect(appearance.classList.contains('active')).toBe(true);
  });

  it('moves left from a content boundary back to the active category', () => {
    settings.render();
    click('[data-settings-target="guide"]');
    container.querySelector<HTMLElement>('#add-epg-source')!
      .dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    settings.handleAction('left');
    expect(container.querySelector('[data-settings-target="guide"]')?.classList.contains('focused'))
      .toBe(true);
  });

  it('brings a picked category to the top of the pane and marks it', () => {
    settings.render();
    const main = container.querySelector<HTMLElement>('.settings-scroll')!;
    const target = container.querySelector<HTMLElement>('#settings-subtitles')!;
    let scrolled = 0;
    Object.defineProperty(main, 'scrollTop', {
      configurable: true, get: () => scrolled, set: (v: number) => { scrolled = v; },
    });
    Object.defineProperty(main, 'scrollHeight', { value: 2000, configurable: true });
    Object.defineProperty(main, 'clientHeight', { value: 800, configurable: true });
    main.getBoundingClientRect = () => ({ top: 0 } as DOMRect);
    target.getBoundingClientRect = () => ({ top: 300 - scrolled } as DOMRect);

    click('[data-settings-target="subtitles"]');

    expect(target.getBoundingClientRect().top).toBe(main.getBoundingClientRect().top);
    expect(container.querySelector('.settings-nav-item.active')?.getAttribute('data-settings-target'))
      .toBe('subtitles');
  });

  it('updates the weak active category when content scrolling reaches the bottom', async () => {
    settings.render();
    const main = container.querySelector<HTMLElement>('.settings-scroll')!;
    Object.defineProperties(main, {
      scrollTop: { value: 900, configurable: true },
      clientHeight: { value: 100, configurable: true },
      scrollHeight: { value: 1000, configurable: true },
    });
    main.dispatchEvent(new Event('scroll'));
    await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
    expect(container.querySelector('.settings-nav-item.active')?.getAttribute('data-settings-target'))
      .toBe('data');
  });

  it('keeps the active category while Magic Remote hover moves elsewhere', () => {
    settings.render();
    click('[data-settings-target="appearance"]');
    container.querySelector<HTMLElement>('[data-settings-target="playback"]')!
      .dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));
    expect(container.querySelector('.settings-nav-item.active')?.getAttribute('data-settings-target'))
      .toBe('appearance');
    expect(container.querySelector('[data-settings-target="playback"]')?.classList.contains('focused'))
      .toBe(true);
  });
});

describe('Settings uploads section', () => {
  beforeEach(() => {
    state.playlists = [
      { name: 'Manual', url: 'http://manual', source: 'url' },
      { name: 'From Phone', url: 'http://127.0.0.1:8890/uploads/from-phone.m3u', source: 'upload' },
    ];
  });

  it('renders uploaded playlists in the upload section, not the URL editor', () => {
    settings.render();
    expect(container.querySelectorAll('#playlist-entries .settings-row:not(.playlist-header-row)')).toHaveLength(1);
    expect(container.querySelector('#playlist-entries input.playlist-name')!).toHaveProperty('value', 'Manual');
    const uploadRows = container.querySelectorAll('#upload-entries .settings-row');
    expect(uploadRows).toHaveLength(1);
    expect(uploadRows[0].querySelector('label')!.textContent).toBe('From Phone');
    expect(uploadRows[0].querySelector<HTMLElement>('.remove-upload')!.dataset.url)
      .toBe('http://127.0.0.1:8890/uploads/from-phone.m3u');
  });

  it('appends the channel count to the upload label when stored', () => {
    state.playlists = [
      { name: 'My Phone List', url: 'http://127.0.0.1:8890/uploads/p.m3u', source: 'upload', count: 12 },
    ];
    settings.render();
    expect(container.querySelector('#upload-entries label')!.textContent)
      .toBe('My Phone List — 12 channels');
  });

  it('uses singular "channel" when the count is exactly 1', () => {
    state.playlists = [
      { name: 'Solo', url: 'http://127.0.0.1:8890/uploads/solo.m3u', source: 'upload', count: 1 },
    ];
    settings.render();
    expect(container.querySelector('#upload-entries label')!.textContent)
      .toBe('Solo — 1 channel');
  });

  it('falls back to the bare name when no count is available (offline / pre-reconcile storage)', () => {
    state.playlists = [
      { name: 'Anon', url: 'http://127.0.0.1:8890/uploads/anon.m3u', source: 'upload' },
    ];
    settings.render();
    expect(container.querySelector('#upload-entries label')!.textContent).toBe('Anon');
  });

  it('shows the empty-hint when there are no uploaded playlists', () => {
    state.playlists = [];
    settings.render();
    expect(container.querySelector('#upload-entries .empty-hint')?.textContent)
      .toBe('No uploaded playlists');
  });

  it('escapes a malicious upload name (no live element injected)', () => {
    state.playlists = [
      { name: '<img src=x onerror=alert(1)>', url: 'http://127.0.0.1:8890/uploads/x.m3u', source: 'upload' },
    ];
    settings.render();
    expect(container.querySelector('#upload-entries img')).toBeNull();
    expect(container.querySelector('#upload-entries label')!.textContent)
      .toContain('<img src=x onerror=');
  });

  it('removeUpload calls the service, drops the entry from storage, and toasts', async () => {
    settings.render();
    container.querySelector<HTMLElement>('.remove-upload')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    // settings.removeUpload is async (awaits UploadClient.remove); flush microtasks.
    await new Promise((r) => setTimeout(r, 0));

    expect(uploadMock.remove).toHaveBeenCalledWith('from-phone');
    expect(storageMock.setPlaylists).toHaveBeenCalledWith([
      { name: 'Manual', url: 'http://manual', source: 'url' },
    ]);
    expect(toastMock.showToast).toHaveBeenCalledWith('Uploaded playlist removed');
  });

  it('save() preserves uploaded playlists alongside the edited URL list', () => {
    settings.render();
    const urls = container.querySelectorAll<HTMLInputElement>('.playlist-url');
    urls[0].value = 'http://renamed';
    container.querySelector<HTMLElement>('#save-settings')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));

    expect(storageMock.setPlaylists).toHaveBeenCalledWith([
      { id: expect.any(String), name: 'Manual', url: 'http://renamed', source: 'url' },
      { name: 'From Phone', url: 'http://127.0.0.1:8890/uploads/from-phone.m3u', source: 'upload' },
    ]);
  });

  it('renders the QR + URL when the setup service is reachable', async () => {
    setupMock.getInfo.mockResolvedValueOnce({
      ip: '192.168.1.2',
      port: 8890,
      setupUrl: 'http://192.168.1.2:8890/setup?token=abc123',
      manualUrl: 'http://192.168.1.2:8890',
      pairingCode: '1234',
    });
    settings.render();
    await new Promise((r) => setTimeout(r, 0));
    const info = container.querySelector('#setup-info')!;
    expect(info.closest('#settings-general')).not.toBeNull();
    expect(info.querySelector('.setup-url')!.textContent).toBe('http://192.168.1.2:8890');
    expect(info.querySelector('.setup-pairing-code')!.textContent).toContain('1234');
    const img = info.querySelector<HTMLImageElement>('img.setup-qr');
    expect(img).not.toBeNull();
    expect(img!.src.startsWith('data:image/')).toBe(true);
  });

  it('shows an unavailable message when the setup service is unreachable', async () => {
    // Default mock returns null -> service unreachable.
    settings.render();
    await new Promise((r) => setTimeout(r, 0));
    expect(container.querySelector('#setup-info')!.textContent)
      .toContain('The setup service is currently unavailable.');
  });

  it('replaces the early unavailable state when the service becomes ready', async () => {
    settings.render();
    await new Promise((r) => setTimeout(r, 0));
    setupMock.getInfo.mockResolvedValueOnce({
      ip: '192.168.1.2',
      port: 8890,
      setupUrl: 'http://192.168.1.2:8890/setup?token=abc123',
      manualUrl: 'http://192.168.1.2:8890',
      pairingCode: '1234',
    });

    await settings.refreshSetupInfo();

    expect(container.querySelector('#setup-info .setup-url')?.textContent)
      .toBe('http://192.168.1.2:8890');
    expect(container.querySelector('#setup-info .setup-qr')).not.toBeNull();
  });
});

describe('Settings uploads auto-refresh', () => {
  // Settings reconciles + morphs the upload list on open. While the view is
  // open, app.ts subscribes to the LAN service's Luna `serviceEvents` push
  // channel and calls settings.refreshUploads() on each push (event-driven,
  // no polling).

  beforeEach(() => {
    // Open Settings with no uploads visible.
    state.playlists = [];
  });

  it('reconciles on render so an upload that arrived before opening shows up', async () => {
    // Simulate reconcile pulling in a new upload from the service.
    uploadMock.reconcile.mockImplementationOnce(async () => {
      state.playlists = [
        { name: 'Channel One', url: 'http://127.0.0.1:8890/uploads/channel-one.m3u', source: 'upload' },
      ];
    });

    settings.render();
    // First render reads empty storage → empty hint
    expect(container.querySelector('#upload-entries .empty-hint')).not.toBeNull();

    // Flush refreshUploads (reconcile resolves, then morph applies)
    await Promise.resolve();
    await Promise.resolve();

    expect(uploadMock.reconcile).toHaveBeenCalled();
    const rows = container.querySelectorAll('#upload-entries .settings-row');
    expect(rows).toHaveLength(1);
    expect(rows[0].querySelector('label')!.textContent).toBe('Channel One');
    expect(container.querySelector('#upload-entries .empty-hint')).toBeNull();
  });

  it('refreshUploads() (the public hook fired by app.ts on each Luna push) reconciles + morphs in place', async () => {
    settings.render();
    await Promise.resolve(); await Promise.resolve();
    uploadMock.reconcile.mockClear();

    // Simulate a LAN service push: a new uploaded file arrived.
    uploadMock.reconcile.mockImplementationOnce(async () => {
      state.playlists = [
        { name: 'Pushed', url: 'http://127.0.0.1:8890/uploads/pushed.m3u', source: 'upload' },
      ];
    });

    await settings.refreshUploads();

    expect(uploadMock.reconcile).toHaveBeenCalledTimes(1);
    const rows = container.querySelectorAll('#upload-entries .settings-row');
    expect(rows).toHaveLength(1);
    expect(rows[0].querySelector('label')!.textContent).toBe('Pushed');
  });

  it('keeps upload toggles and pending state when the upload list refreshes', async () => {
    state.playlists = [{
      id: 'upload-source',
      name: 'Pushed',
      url: 'http://127.0.0.1:8890/uploads/pushed.m3u',
      source: 'upload',
      enabled: false,
    }];
    settings.render();
    await Promise.resolve(); await Promise.resolve();
    const toggle = container.querySelector<HTMLElement>('#upload-entries .source-toggle')!;
    expect(toggle.dataset.enabled).toBe('false');

    toggle.click();
    await settings.refreshUploads();

    expect(container.querySelector<HTMLElement>('#upload-entries .source-toggle')
      ?.dataset.enabled).toBe('true');
    click('#save-settings');
    expect(storageMock.setPlaylists).toHaveBeenCalledWith([
      expect.objectContaining({ id: 'upload-source', source: 'upload' }),
    ]);
    const calls = storageMock.setPlaylists.mock.calls;
    expect(calls[calls.length - 1][0][0]).not.toHaveProperty('enabled');
  });

  it('refreshUploads() can be called when settings has never rendered (event arrives early) without throwing', async () => {
    // No render() yet — #upload-entries doesn't exist in the DOM.
    uploadMock.reconcile.mockImplementationOnce(async () => {
      state.playlists = [
        { name: 'Early', url: 'http://127.0.0.1:8890/uploads/early.m3u', source: 'upload' },
      ];
    });

    await expect(settings.refreshUploads()).resolves.toBeUndefined();
    // Reconcile still runs (storage gets updated), only the morph is skipped.
    expect(uploadMock.reconcile).toHaveBeenCalledTimes(1);
  });

  it('removes the empty-hint and replaces with rows in a single morph (no flicker)', async () => {
    uploadMock.reconcile.mockImplementationOnce(async () => {
      state.playlists = [
        { name: 'A', url: 'http://127.0.0.1:8890/uploads/a.m3u', source: 'upload' },
        { name: 'B', url: 'http://127.0.0.1:8890/uploads/b.m3u', source: 'upload' },
      ];
    });

    settings.render();
    await Promise.resolve(); await Promise.resolve();

    const labels = Array.from(container.querySelectorAll('#upload-entries label'))
      .map((l) => l.textContent);
    expect(labels).toEqual(['A', 'B']);
    // Each row has a stable data-key for morph identity.
    const keys = Array.from(container.querySelectorAll<HTMLElement>('#upload-entries .settings-row'))
      .map((r) => r.getAttribute('data-key'));
    expect(keys).toEqual([
      'http://127.0.0.1:8890/uploads/a.m3u',
      'http://127.0.0.1:8890/uploads/b.m3u',
    ]);
  });
});

describe('Settings listener lifecycle', () => {
  it('binds persistent-container listeners once, not per render', () => {
    const c = document.createElement('div');
    document.body.appendChild(c);
    const spy = vi.spyOn(c, 'addEventListener');
    settings.focusScope.dispose();
    const s = new Settings(c, vi.fn());
    s.render();
    s.render();
    s.render();
    const count = (type: string) =>
      spy.mock.calls.filter(([t]) => t === type).length;
    expect(count('nav:hover')).toBe(1);
    expect(count('keydown')).toBe(1);
    expect(count('click')).toBe(1);
  });
});

describe('Settings Xtream section', () => {
  it('renders credential fields with stored values for an xtream account', () => {
    state.playlists = [{
      id: 'x1', name: 'My Provider', url: 'http://host:8080',
      source: 'xtream', xtream: { username: 'user1', password: 'pass1' },
    }];
    settings.render();
    const card = container.querySelector('#xtream-entries .xtream-card')!;
    expect(card).not.toBeNull();
    expect(card.querySelector<HTMLInputElement>('.xtream-name')!.value).toBe('My Provider');
    expect(card.querySelector<HTMLInputElement>('.xtream-url')!.value).toBe('http://host:8080');
    expect(card.querySelector<HTMLInputElement>('.xtream-username')!.value).toBe('user1');
    expect(card.querySelector<HTMLElement>('.xtream-output .dropdown')!.dataset.value).toBe('ts');
    const pw = card.querySelector<HTMLInputElement>('.xtream-password')!;
    expect(pw.value).toBe('pass1');
    expect(pw.type).toBe('password');
  });

  it('renders and preserves a disabled Xtream account', () => {
    state.playlists = [{
      id: 'x1', name: 'My Provider', url: 'http://host:8080', source: 'xtream',
      enabled: false, xtream: { username: 'user1', password: 'pass1' },
    }];
    settings.render();
    const card = container.querySelector<HTMLElement>('#xtream-entries .xtream-card')!;
    expect(card.classList.contains('source-disabled')).toBe(true);
    expect(card.querySelector<HTMLElement>('.source-toggle')?.dataset.enabled).toBe('false');

    click('#save-settings');

    const saved = storageMock.setPlaylists.mock.calls.at(-1)![0] as PlaylistEntry[];
    expect(saved[0].enabled).toBe(false);
  });

  it('keeps xtream accounts out of the M3U Playlists list', () => {
    state.playlists = [
      { id: 'p1', name: 'M3U', url: 'http://m3u', source: 'url' },
      { id: 'x1', name: 'Acct', url: 'http://host:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
    ];
    settings.render();
    const rows = container.querySelectorAll('#playlist-entries .settings-row:not(.playlist-header-row)');
    expect(rows).toHaveLength(1);
    expect(rows[0].querySelector<HTMLInputElement>('.playlist-url')!.value).toBe('http://m3u');
    expect(container.querySelectorAll('#xtream-entries .xtream-card')).toHaveLength(1);
  });

  it('shows the empty hint when no xtream accounts are configured', () => {
    state.playlists = [];
    settings.render();
    expect(container.querySelector('#xtream-entries .xtream-card')).toBeNull();
    expect(container.querySelector('#xtream-entries .empty-hint')?.textContent)
      .toBe('No Xtream accounts added yet');
    expect(container.querySelector<HTMLElement>('#add-xtream')).not.toBeNull();
  });

  it('places phone setup beside Language and keeps Xtream Accounts above Playlists', () => {
    settings.render();
    const heads = Array.from(container.querySelectorAll('.settings-section-title'))
      .map((h) => h.textContent);
    expect(heads[0]).toBe('Language');
    expect(heads[1]).toBe('Set up with your phone or computer');
    expect(container.querySelector('#app-language')?.closest('.settings-general-row'))
      .toBe(container.querySelector('#setup-info')?.closest('.settings-general-row'));
    expect(heads.indexOf('Language')).toBeLessThan(heads.indexOf('Xtream Accounts'));
    expect(heads.indexOf('Xtream Accounts')).toBeLessThan(heads.indexOf('Playlists'));
  });

  it('shows the phone setup QR panel without an extra action', () => {
    settings.render();
    const panel = container.querySelector<HTMLElement>('#setup-info')!;
    expect(panel.classList.contains('hidden')).toBe(false);
    expect(container.querySelector('#phone-setup-toggle')).toBeNull();
  });

  it('adds a blank xtream card and drops the empty hint', () => {
    state.playlists = [];
    settings.render();
    expect(container.querySelector<HTMLElement>('#add-xtream')).not.toBeNull();
    click('#add-xtream');
    expect(container.querySelectorAll('#xtream-entries .xtream-card')).toHaveLength(1);
    expect(container.querySelector('#xtream-entries .empty-hint')).toBeNull();
    const card = container.querySelector('#xtream-entries .xtream-card')!;
    expect(card.querySelector<HTMLElement>('.xtream-card')).toBeNull(); // one card, not nested
    expect(card.getAttribute('data-id')).toBeTruthy(); // seeded a stable id
  });

  it('removes an xtream card and restores the empty hint when the last one goes', () => {
    state.playlists = [
      { id: 'x1', name: 'Acct', url: 'http://host:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
    ];
    settings.render();
    expect(container.querySelectorAll('#xtream-entries .xtream-card')).toHaveLength(1);
    click('#xtream-entries .remove-xtream');
    expect(container.querySelectorAll('#xtream-entries .xtream-card')).toHaveLength(0);
    expect(container.querySelector('#xtream-entries .empty-hint')?.textContent)
      .toBe('No Xtream accounts added yet');
  });

  it('removes only the card whose button was clicked', () => {
    state.playlists = [
      { id: 'x1', name: 'A', url: 'http://a:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
      { id: 'x2', name: 'B', url: 'http://b:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
    ];
    settings.render();
    const cardB = Array.from(container.querySelectorAll<HTMLElement>('#xtream-entries .xtream-card'))
      .find(c => c.dataset.id === 'x1')!; // remove the first
    cardB.querySelector<HTMLElement>('.remove-xtream')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    const remaining = Array.from(container.querySelectorAll<HTMLElement>('#xtream-entries .xtream-card'));
    expect(remaining).toHaveLength(1);
    expect(remaining[0].dataset.id).toBe('x2');
  });

  function fillCard(card: HTMLElement, v: { name?: string; url?: string; user?: string; pass?: string }): void {
    if (v.name !== undefined) card.querySelector<HTMLInputElement>('.xtream-name')!.value = v.name;
    if (v.url !== undefined) card.querySelector<HTMLInputElement>('.xtream-url')!.value = v.url;
    if (v.user !== undefined) card.querySelector<HTMLInputElement>('.xtream-username')!.value = v.user;
    if (v.pass !== undefined) card.querySelector<HTMLInputElement>('.xtream-password')!.value = v.pass;
  }

  it('saves a complete card as a source:xtream entry (normalized url) and reloads', () => {
    state.playlists = [{ id: 'p1', name: 'M3U', url: 'http://m3u', source: 'url' }];
    settings.render();
    click('#add-xtream');
    const card = container.querySelector<HTMLElement>('#xtream-entries .xtream-card')!;
    fillCard(card, { name: 'My Provider', url: 'host:8080/', user: 'user1', pass: 'pass1' });
    const id = card.dataset.id!;

    click('#save-settings');

    expect(storageMock.setPlaylists).toHaveBeenCalledWith([
      { id: 'p1', name: 'M3U', url: 'http://m3u', source: 'url' },
      {
        id,
        name: 'My Provider',
        url: 'http://host:8080',
        source: 'xtream',
        xtream: { username: 'user1', password: 'pass1', liveOutput: 'ts' },
      },
    ]);
    expect(onSave).toHaveBeenCalledWith('reload');
  });

  it('persists an explicit HLS preference', () => {
    state.playlists = [{
      id: 'x1', name: 'Acct', url: 'http://host:8080',
      source: 'xtream', xtream: { username: 'u', password: 'p' },
    }];
    settings.render();
    click('#xtream-output-x1 [data-dropdown-value="m3u8"]');
    click('#save-settings');
    const saved = storageMock.setPlaylists.mock.calls.at(-1)![0] as PlaylistEntry[];
    expect(saved[0].xtream?.liveOutput).toBe('m3u8');
    expect(onSave).toHaveBeenCalledWith('reload');
  });

  it('falls back to the host as the label when none is given', () => {
    state.playlists = [];
    settings.render();
    click('#add-xtream');
    const card = container.querySelector<HTMLElement>('#xtream-entries .xtream-card')!;
    fillCard(card, { url: 'http://host:8080', user: 'u', pass: 'p' });
    click('#save-settings');
    const saved = storageMock.setPlaylists.mock.calls.at(-1)![0] as { name: string }[];
    expect(saved).toHaveLength(1);
    expect(saved[0].name).toBe('host:8080');
  });

  it('skips an incomplete card (missing a credential) rather than persist a broken account', () => {
    state.playlists = [];
    settings.render();
    click('#add-xtream'); // complete
    click('#add-xtream'); // missing password
    const cards = container.querySelectorAll<HTMLElement>('#xtream-entries .xtream-card');
    fillCard(cards[0], { name: 'A', url: 'http://a:8080', user: 'u', pass: 'p' });
    fillCard(cards[1], { name: 'B', url: 'http://b:8080', user: 'u', pass: '' });
    click('#save-settings');
    const saved = storageMock.setPlaylists.mock.calls.at(-1)![0] as { name: string; source?: string }[];
    const xtream = saved.filter(p => p.source === 'xtream');
    expect(xtream).toHaveLength(1);
    expect(xtream[0].name).toBe('A');
  });

  const flush = () => new Promise((r) => setTimeout(r, 0));

  it('Check shows status, expiry and connections for a verified account', async () => {
    state.playlists = [
      { id: 'x1', name: 'Acct', url: 'http://host:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
    ];
    settings.render();
    xtreamMock.getAccountInfo.mockResolvedValueOnce({
      auth: true, status: 'Active', expiresAt: 1786000000, maxConnections: 2, activeConnections: 1,
      allowedOutputFormats: ['ts', 'm3u8'],
    });
    click('#xtream-entries .check-xtream');
    await flush();
    const status = container.querySelector('#xtream-entries .xtream-status')!;
    expect(status.classList.contains('ok')).toBe(true);
    expect(status.textContent).toContain('Active');
    expect(status.textContent).toMatch(/expires \d{4}-\d{2}-\d{2}/);
    expect(status.textContent).toContain('1/2');
  });

  it('Check reports a login failure for auth:0', async () => {
    state.playlists = [
      { id: 'x1', name: 'Acct', url: 'http://host:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
    ];
    settings.render();
    xtreamMock.getAccountInfo.mockResolvedValueOnce({
      auth: false, status: '', expiresAt: null, maxConnections: 0, activeConnections: 0,
      allowedOutputFormats: [],
    });
    click('#xtream-entries .check-xtream');
    await flush();
    const status = container.querySelector('#xtream-entries .xtream-status')!;
    expect(status.classList.contains('err')).toBe(true);
    expect(status.textContent).toContain('Login failed');
  });

  it('Check prompts to complete the fields when a credential is missing, without a lookup', async () => {
    state.playlists = [];
    settings.render();
    click('#add-xtream');
    const card = container.querySelector<HTMLElement>('#xtream-entries .xtream-card')!;
    fillCard(card, { url: 'http://host:8080', user: 'u', pass: '' }); // no password
    card.querySelector<HTMLElement>('.check-xtream')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    await flush();
    expect(xtreamMock.getAccountInfo).not.toHaveBeenCalled();
    const status = card.querySelector('.xtream-status')!;
    expect(status.classList.contains('err')).toBe(true);
    expect(status.textContent).toContain('server URL, username, and password');
  });

  it('Check reports a verify failure when the panel is unreachable (null)', async () => {
    state.playlists = [
      { id: 'x1', name: 'Acct', url: 'http://host:8080', source: 'xtream', xtream: { username: 'u', password: 'p' } },
    ];
    settings.render();
    xtreamMock.getAccountInfo.mockResolvedValueOnce(null);
    click('#xtream-entries .check-xtream');
    await flush();
    const status = container.querySelector('#xtream-entries .xtream-status')!;
    expect(status.classList.contains('err')).toBe(true);
    expect(status.textContent).toContain('verify');
  });
});

describe('Settings Xtream Live categories', () => {
  const snapshots = new Map<string, XtreamLiveCategorySnapshot>();
  const account = (over: Partial<PlaylistEntry['xtream']> = {}) => ({
    id: 'x1', name: 'Acct', url: 'http://host:8080', source: 'xtream' as const,
    xtream: { username: 'u', password: 'p', ...over },
  });
  const flush = () => new Promise((r) => setTimeout(r, 0));
  const picker = () => document.body.querySelector<HTMLElement>('.live-category-picker');
  const button = () => container.querySelector<HTMLElement>('#xtream-entries .xtream-live-categories')!;
  const savedXtream = () => (storageMock.setPlaylists.mock.calls.at(-1)![0] as PlaylistEntry[])
    .filter(pl => pl.source === 'xtream');

  beforeEach(() => {
    snapshots.clear();
    storageMock.getLiveCategorySnapshot.mockImplementation(
      ((id: string) => snapshots.get(id) ?? null) as () => null,
    );
    xtreamMock.getLiveCategories.mockResolvedValue([
      { id: 'c1', name: 'Alpha', parentId: '' },
      { id: 'c2', name: 'Bravo', parentId: '' },
      { id: 'c3', name: 'Charlie', parentId: '' },
    ]);
  });

  afterEach(() => {
    storageMock.getLiveCategorySnapshot.mockImplementation(() => null);
    xtreamMock.getLiveCategories.mockResolvedValue([]);
  });

  it('shows All on the card when the account has no filter', () => {
    state.playlists = [account()];
    settings.render();
    const btn = button();
    const foot = btn.parentElement!;
    expect(foot.querySelector('.check-xtream')!.nextElementSibling).toBe(btn);
    expect(btn.querySelector('.xtream-live-categories-value')?.textContent).toBe('All');
    expect(btn.querySelector('.xtream-live-categories-new')).toBeNull();
  });

  it('shows the kept share and a badge for unseen categories in include mode', () => {
    state.playlists = [account({ liveCategories: { mode: 'include', ids: ['c1'] } })];
    snapshots.set('x1', {
      knownIds: ['c1', 'c2'],
      announcedIds: ['c3', 'c4'],
      counts: { c1: 4, c2: 2, c3: 1, c4: 1 },
    });
    settings.render();
    expect(button().querySelector('.xtream-live-categories-value')?.textContent).toBe('1 of 4');
    expect(button().querySelector('.xtream-live-categories-new')?.textContent).toBe('2 new');
  });

  it('counts kept categories in exclude mode without a new badge', () => {
    state.playlists = [account({ liveCategories: { mode: 'exclude', ids: ['c2'] } })];
    snapshots.set('x1', {
      knownIds: ['c1', 'c2'],
      announcedIds: [],
      counts: { c1: 4, c2: 2, c3: 1 },
    });
    settings.render();
    expect(button().querySelector('.xtream-live-categories-value')?.textContent).toBe('2 of 3');
    expect(button().querySelector('.xtream-live-categories-new')).toBeNull();
  });

  it('omits the share while the catalog size is unknown', () => {
    const content = document.createElement('div');
    morph(content, liveCategoriesButtonContent({ mode: 'include', ids: ['c1'] }, null));
    expect(content.querySelector('.xtream-live-categories-value')).toBeNull();
    expect(content.textContent).toBe('Live categories');
  });

  it('keeps the stored filter on save while the server and username are unchanged', () => {
    const liveCategories = { mode: 'include' as const, ids: ['c1'] };
    state.playlists = [account({ liveCategories })];
    settings.render();
    const card = container.querySelector<HTMLElement>('#xtream-entries .xtream-card')!;
    card.querySelector<HTMLInputElement>('.xtream-url')!.value = 'host:8080/';
    card.querySelector<HTMLInputElement>('.xtream-password')!.value = 'p2';
    click('#save-settings');
    expect(savedXtream()[0].xtream).toEqual({
      username: 'u', password: 'p2', liveOutput: 'ts', liveCategories,
    });
  });

  it('drops the stored filter on save when the username changes', () => {
    state.playlists = [account({ liveCategories: { mode: 'include', ids: ['c1'] } })];
    settings.render();
    container.querySelector<HTMLInputElement>('#xtream-entries .xtream-username')!.value = 'u2';
    click('#save-settings');
    expect(savedXtream()[0].xtream).toEqual({ username: 'u2', password: 'p', liveOutput: 'ts' });
  });

  it('asks for credentials instead of opening the picker on an incomplete card', async () => {
    state.playlists = [];
    settings.render();
    click('#add-xtream');
    const card = container.querySelector<HTMLElement>('#xtream-entries .xtream-card')!;
    card.querySelector<HTMLInputElement>('.xtream-url')!.value = 'http://host:8080';
    card.querySelector<HTMLInputElement>('.xtream-username')!.value = 'u';
    card.querySelector<HTMLElement>('.xtream-live-categories')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    await flush();

    const status = card.querySelector('.xtream-status')!;
    expect(status.classList.contains('err')).toBe(true);
    expect(status.textContent).toContain('server URL, username, and password');
    expect(settings.isPromptVisible).toBe(false);
    expect(picker()?.classList.contains('hidden') ?? true).toBe(true);
    expect(xtreamMock.getLiveCategories).not.toHaveBeenCalled();
  });

  it('saves the picker result for the same account and records a reviewed snapshot', async () => {
    state.playlists = [account()];
    snapshots.set('x1', { knownIds: ['c1', 'c9'], announcedIds: ['c3'], counts: { c1: 5, c9: 2 } });
    settings.render();
    click('#xtream-entries .xtream-live-categories');
    await flush();

    expect(settings.isPromptVisible).toBe(true);
    expect(picker()!.classList.contains('hidden')).toBe(false);
    picker()!.querySelector<HTMLElement>('[data-category-id="c2"]')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    Focus.owner()!.handle('yellow');

    expect(settings.isPromptVisible).toBe(false);
    expect(storageMock.setLiveCategorySnapshot).toHaveBeenCalledWith('x1', {
      knownIds: ['c1', 'c2', 'c3'],
      announcedIds: [],
      counts: { c1: 5 },
    });
    expect(button().querySelector('.xtream-live-categories-value')?.textContent).toBe('2 of 3');

    click('#save-settings');
    expect(savedXtream()[0].xtream?.liveCategories).toEqual({ mode: 'include', ids: ['c1', 'c3'] });
    expect(onSave).toHaveBeenCalledWith('reload');
  });

  it('drops a picker result when the username changes before save', async () => {
    state.playlists = [account()];
    settings.render();
    click('#xtream-entries .xtream-live-categories');
    await flush();
    picker()!.querySelector<HTMLElement>('[data-category-id="c2"]')!
      .dispatchEvent(new MouseEvent('click', { bubbles: true }));
    Focus.owner()!.handle('yellow');
    container.querySelector<HTMLInputElement>('#xtream-entries .xtream-username')!.value = 'u2';

    click('#save-settings');

    expect(savedXtream()[0].xtream?.liveCategories).toBeUndefined();
  });

  it('keeps the reviewed snapshot when the account is re-pointed before the picker opens', async () => {
    state.playlists = [account()];
    snapshots.set('x1', { knownIds: ['c1'], announcedIds: [], counts: {} });
    storageMock.setLiveCategorySnapshot.mockImplementation(
      ((id: string, snap: XtreamLiveCategorySnapshot) => { snapshots.set(id, snap); }) as () => void,
    );
    // Mirrors StorageService pruning the snapshot of a re-pointed account.
    storageMock.setPlaylists.mockImplementation((() => { snapshots.clear(); return true; }) as () => boolean);
    settings.render();
    container.querySelector<HTMLInputElement>('#xtream-entries .xtream-username')!.value = 'u2';
    click('#xtream-entries .xtream-live-categories');
    await flush();
    Focus.owner()!.handle('yellow');
    expect(storageMock.setLiveCategorySnapshot).not.toHaveBeenCalled();
    expect(snapshots.get('x1')).toEqual({ knownIds: ['c1'], announcedIds: [], counts: {} });

    click('#save-settings');

    expect(savedXtream()[0].xtream?.username).toBe('u2');
    expect(snapshots.get('x1')).toEqual({ knownIds: ['c1', 'c2', 'c3'], announcedIds: [], counts: {} });
    storageMock.setLiveCategorySnapshot.mockReset();
    storageMock.setPlaylists.mockReset();
  });

  it('does not write a re-pointed account snapshot when saving the playlists fails', async () => {
    state.playlists = [account()];
    storageMock.setPlaylists.mockReturnValue(false);
    settings.render();
    container.querySelector<HTMLInputElement>('#xtream-entries .xtream-username')!.value = 'u2';
    click('#xtream-entries .xtream-live-categories');
    await flush();
    Focus.owner()!.handle('yellow');

    click('#save-settings');

    expect(storageMock.setPlaylists).toHaveBeenCalled();
    expect(storageMock.setLiveCategorySnapshot).not.toHaveBeenCalled();
    storageMock.setPlaylists.mockReset();
  });

  it('routes actions to the open picker and hides it on dismissPrompt', async () => {
    state.playlists = [account({ liveCategories: { mode: 'include', ids: ['c1'] } })];
    settings.render();
    click('#xtream-entries .xtream-live-categories');
    await flush();
    expect(settings.isPromptVisible).toBe(true);

    settings.dismissPrompt();

    expect(settings.isPromptVisible).toBe(false);
    expect(picker()!.classList.contains('hidden')).toBe(true);
    expect(storageMock.setLiveCategorySnapshot).not.toHaveBeenCalled();
    click('#save-settings');
    expect(savedXtream()[0].xtream?.liveCategories).toEqual({ mode: 'include', ids: ['c1'] });
  });
});
