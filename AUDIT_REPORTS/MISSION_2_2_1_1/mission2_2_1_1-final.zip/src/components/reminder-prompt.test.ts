// @vitest-environment jsdom
import { describe, it, expect, afterEach, beforeEach, vi } from 'vitest';
import { Focus } from '../navigation/focus-scope';
import { ReminderPrompt } from './reminder-prompt';

let prompt: ReminderPrompt;
beforeEach(() => { document.body.innerHTML = ''; prompt = new ReminderPrompt(); });
afterEach(() => Focus.uninstall());

const buttons = () => Array.from(document.querySelectorAll('.reminder-btn'));

describe('ReminderPrompt', () => {
  it('renders the title and Watch now/Cancel and starts focused on Watch now', () => {
    prompt.show('Alpha', 'Bravo', { onConfirm: vi.fn(), onCancel: vi.fn() });
    expect(prompt.visible).toBe(true);
    expect(document.querySelector('.reminder-message')!.textContent).toContain('Bravo — Alpha');
    expect(buttons().map(b => b.textContent)).toEqual(['Watch now', 'Cancel']);
    expect(document.querySelector('.reminder-btn.focused')!.textContent).toBe('Watch now');
  });

  it('select on Watch now confirms and hides', () => {
    const onConfirm = vi.fn();
    prompt.show('Alpha', 'Bravo', { onConfirm, onCancel: vi.fn() });
    prompt.handleAction('select');
    expect(onConfirm).toHaveBeenCalledTimes(1);
    expect(prompt.visible).toBe(false);
  });

  it('right then select cancels; back cancels', () => {
    const onCancel = vi.fn();
    prompt.show('Alpha', 'Bravo', { onConfirm: vi.fn(), onCancel });
    prompt.handleAction('right');
    expect(document.querySelector('.reminder-btn.focused')!.textContent).toBe('Cancel');
    prompt.handleAction('select');
    expect(onCancel).toHaveBeenCalledTimes(1);

    const onCancel2 = vi.fn();
    prompt.show('Beta', 'Charlie', { onConfirm: vi.fn(), onCancel: onCancel2 });
    prompt.handleAction('back');
    expect(onCancel2).toHaveBeenCalledTimes(1);
  });

  it('shows the generic locked message without the names', () => {
    prompt.show('Alpha', 'Bravo', { onConfirm: vi.fn(), onCancel: vi.fn() }, true);
    const message = document.querySelector('.reminder-message')!.textContent!;
    expect(message).toBe('A locked program is now live. Watch now?');
  });

  it('escapes the title (no raw HTML injection)', () => {
    prompt.show('<img src=x>', 'Bravo', { onConfirm: vi.fn(), onCancel: vi.fn() });
    expect(document.querySelector('.reminder-message img')).toBeNull();
  });

  it('moves focus to the button under the pointer', () => {
    const onCancel = vi.fn();
    prompt.show('Alpha', 'Bravo', { onConfirm: vi.fn(), onCancel });
    document.querySelector<HTMLElement>('[data-reminder-action="cancel"]')!
      .dispatchEvent(new CustomEvent('nav:hover', { bubbles: true }));

    expect(document.querySelector('.reminder-btn.focused')!.textContent).toBe('Cancel');
    prompt.handleAction('select');
    expect(onCancel).toHaveBeenCalledTimes(1);
  });

  it('owns the keys at the prompt tier while shown', () => {
    prompt.show('Alpha', 'Bravo', { onConfirm: vi.fn(), onCancel: vi.fn() });
    expect(Focus.owner()?.id).toBe('prompt.reminder');
    prompt.handleAction('back');
    expect(Focus.owner()).toBeNull();
  });
});
