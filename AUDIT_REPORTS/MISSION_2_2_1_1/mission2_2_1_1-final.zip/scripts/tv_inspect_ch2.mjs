import { createCdpClient } from './tv_cdp.mjs';

async function main() {
  const cdp = await createCdpClient();
  const res = await cdp.evaluate(`(() => {
    const ch2 = document.querySelector('[data-key="ch:2"]');
    return ch2 ? ch2.outerHTML : 'ch:2 not found';
  })()`);

  console.log('Outer HTML of ch:2:\n', res);
  cdp.close();
}

main().catch(console.error);

