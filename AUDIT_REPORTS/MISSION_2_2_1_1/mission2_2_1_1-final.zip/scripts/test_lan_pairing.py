import urllib.request
import urllib.error
import json
import time

BASE_URL = "http://192.168.1.8:43992"

results = []

def record(name, status, details):
    results.append({"test": name, "status": status, "details": details})
    print(f"[{status}] {name}: {details}")

# 1. Test /info without token
try:
    req = urllib.request.Request(f"{BASE_URL}/info")
    with urllib.request.urlopen(req) as resp:
        record("Info Without Token", "FAIL", f"Unexpected HTTP {resp.status}")
except urllib.error.HTTPError as e:
    body = e.read().decode('utf-8')
    if e.code == 403 and "appToken" not in body:
        record("Info Without Token", "PASS", f"HTTP {e.code} - Body: {body.strip()}")
    elif e.code == 403:
        record("Info Without Token", "PASS", f"HTTP {e.code} (appToken required, secret not leaked)")
    else:
        record("Info Without Token", "FAIL", f"HTTP {e.code} - Body: {body}")

# 2. Test /setup HTML
try:
    req = urllib.request.Request(f"{BASE_URL}/setup")
    with urllib.request.urlopen(req) as resp:
        body = resp.read().decode('utf-8')
        headers = dict(resp.headers)
        nosniff = headers.get('X-Content-Type-Options', '')
        if resp.status == 200 and "<!DOCTYPE html>" in body and nosniff == "nosniff":
            record("Setup HTML & Headers", "PASS", f"HTTP 200 - nosniff present, HTML len: {len(body)}")
        else:
            record("Setup HTML & Headers", "FAIL", f"HTTP {resp.status} - nosniff: {nosniff}")
except Exception as e:
    record("Setup HTML & Headers", "FAIL", str(e))

# 3. Test Invalid PIN on /pair
payload = json.dumps({"code": "0000"}).encode('utf-8')
try:
    req = urllib.request.Request(f"{BASE_URL}/pair", data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as resp:
        record("Invalid PIN First Attempt", "FAIL", f"Unexpected HTTP {resp.status}")
except urllib.error.HTTPError as e:
    body = e.read().decode('utf-8')
    if e.code == 401:
        record("Invalid PIN First Attempt", "PASS", f"HTTP {e.code} - Body: {body.strip()}")
    else:
        record("Invalid PIN First Attempt", "WARN", f"HTTP {e.code} - Body: {body.strip()}")

# 4. Test Rate Limiting / Brute Force on /pair
print("\nTesting Rate Limiting / 429 Brute-force protection on /pair...")
rate_limited = False
retry_after = None
attempts = 0

for i in range(1, 10):
    attempts += 1
    try:
        req = urllib.request.Request(f"{BASE_URL}/pair", data=payload, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req) as resp:
            pass
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8')
        if e.code == 429:
            rate_limited = True
            try:
                data = json.loads(body)
                retry_after = data.get('retryAfter')
            except:
                pass
            record("Rate Limiting on /pair", "PASS", f"Enforced at attempt {attempts}: HTTP 429 Too Many Requests (retryAfter: {retry_after}s)")
            break
        elif e.code == 401:
            continue
        else:
            record("Rate Limiting on /pair", "FAIL", f"Unexpected HTTP {e.code}: {body}")
            break

if not rate_limited:
    record("Rate Limiting on /pair", "FAIL", f"Rate limit not triggered after {attempts} attempts")

# 5. Test Blocked Client does not leak state
if rate_limited:
    try:
        req = urllib.request.Request(f"{BASE_URL}/pair", data=payload, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req) as resp:
            pass
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8')
        if e.code == 429:
            record("Persistent 429 While Blocked", "PASS", f"Blocked client continues receiving HTTP 429: {body.strip()}")
        else:
            record("Persistent 429 While Blocked", "FAIL", f"Received HTTP {e.code}")

with open("AUDIT_REPORTS/MISSION_2/evidence/lan_pairing_test_results.json", "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("\nAll LAN pairing tests completed successfully.")

