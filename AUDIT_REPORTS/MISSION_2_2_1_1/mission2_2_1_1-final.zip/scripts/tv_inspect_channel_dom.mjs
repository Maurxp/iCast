import { createCdpClient } from './tv_cdp.mjs';

async function main() {
  const cdp = await createCdpClient();
  const res = await cdp.evaluate(`(() => {
    const list = document.getElementById('channel-list') || document.querySelector('.channel-list');
    const items = Array.from(document.querySelectorAll('[data-channel-index], [data-key], .channel, .item')).map(el => ({
      tagName: el.tagName,
      className: el.className,
      dataKey: el.getAttribute('data-key'),
      text: el.innerText ? el.innerText.trim().replace(/\\n+/g, ' | ') : '',
      html: el.innerHTML.substring(0, 200)
    }));

    return {
      listFound: Boolean(list),
      listClasses: list ? list.className : null,
      items: items.filter(it => it.text.includes('Stream') || it.text.includes('MP4') || it.text.includes('HLS') || it.text.includes('DASH'))
    };
  })()`);

  console.log('Channel List Items on TV:\n', JSON.stringify(res, null, 2));
  cdp.close();
}

main().catch(console.error);

