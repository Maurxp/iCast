import { createCdpClient } from './tv_cdp.mjs';

async function main() {
  const cdp = await createCdpClient();
  const res = await cdp.evaluate(`(() => {
    return {
      bodyText: document.body.innerText,
      settingsHtml: document.getElementById('view-settings') ? document.getElementById('view-settings').innerHTML : ''
    };
  })()`);

  console.log('--- BODY TEXT ON TV SCREEN ---');
  console.log(res.bodyText);
  cdp.close();
}

main().catch(console.error);

