#!/bin/sh
set -e

echo "=== CLOSING PREVIOUS INSTANCE (IF RUNNING) ==="
luna-send -n 1 luna://com.webos.applicationManager/closeByAppId '{"id":"com.lennylxx.iptv"}' 2>&1 || true
sleep 1

echo "=== LAUNCHING APP VIA SAM ==="
luna-send -n 1 luna://com.webos.applicationManager/launch '{"id":"com.lennylxx.iptv"}' 2>&1

echo "=== WAITING FOR APP & SERVICE INITIALIZATION ==="
sleep 5

echo "=== CHECKING RUNNING PROCESSES (APP & SERVICE) ==="
ps aux | grep -E "com.lennylxx.iptv|node|webapp" | grep -v grep || true

echo "=== CHECKING LISTENING PORTS FOR LAN SERVICE ==="
netstat -tuln | grep LISTEN || true

echo "=== TEST C.1: UNAUTHORIZED LUNA CALL (FAIL-CLOSED VERIFICATION) ==="
echo "Calling com.lennylxx.iptv.service/start with empty payload from shell:"
luna-send -n 1 luna://com.lennylxx.iptv.service/start '{}' 2>&1 || true

echo "=== TEST C.2: SPOOFED CALLER LUNA CALL ==="
echo "Calling com.lennylxx.iptv.service/start with spoofed caller -a com.attacker.app:"
luna-send -n 1 -a com.attacker.app luna://com.lennylxx.iptv.service/start '{}' 2>&1 || true

echo "=== TEST C.3: PROPER CHECK ON lan/status ==="
luna-send -n 1 luna://com.lennylxx.iptv.service/status '{}' 2>&1 || true

echo "=== PHASE C COMPLETED ==="
