import { createCdpClient } from './tv_cdp.mjs';

async function main() {
  const cdp = await createCdpClient();
  const state = await cdp.evaluate(`(() => {
    const cards = Array.from(document.querySelectorAll('.channel-card, [data-channel-key]')).map(c => ({
      key: c.getAttribute('data-channel-key') || c.getAttribute('data-key'),
      name: c.querySelector('.channel-name, .name') ? c.querySelector('.channel-name, .name').textContent.trim() : '',
      classes: c.className,
      badge: c.querySelector('.health-badge, .badge, .status-indicator') ? c.querySelector('.health-badge, .badge, .status-indicator').className : null,
      innerHtmlSnippet: c.innerHTML.substring(0, 150)
    }));

    const activeView = Array.from(document.querySelectorAll('.view')).find(v => v.style.display !== 'none');
    
    const storage = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      storage[k] = localStorage.getItem(k);
    }

    return {
      activeViewId: activeView ? activeView.id : 'unknown',
      channelCards: cards,
      storageKeys: Object.keys(storage),
      channelHealthStorage: storage['iptv_channel_health'] || null,
      lastView: storage['iptv_last_view'] || null
    };
  })()`);

  console.log('App State on TV:\n', JSON.stringify(state, null, 2));
  cdp.close();
}

main().catch(console.error);

