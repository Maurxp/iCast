import { createCdpClient } from './tv_cdp.mjs';
import * as fs from 'fs';

const testStreams = [
  {
    name: 'MP4 Progressive (H.264 / AAC)',
    format: 'MP4',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    mime: 'video/mp4'
  },
  {
    name: 'HLS Live/VOD (m3u8)',
    format: 'HLS',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    mime: 'application/vnd.apple.mpegurl'
  },
  {
    name: 'MPEG-DASH (mpd)',
    format: 'DASH',
    url: 'https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd',
    mime: 'application/dash+xml'
  }
];

async function runPlaybackTest() {
  const cdp = await createCdpClient();
  console.log('Connected to CDP for playback evaluation.');

  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');

  const results = [];

  for (const stream of testStreams) {
    console.log(`\nTesting format: ${stream.name}...`);
    
    // Reset global test result
    await cdp.evaluate(`window.__testResult = null;`);

    // Start video playback test
    await cdp.evaluate(`(() => {
      const video = document.getElementById('video-player') || document.querySelector('video');
      if (!video) {
        window.__testResult = { error: 'No video element found' };
        return;
      }

      let timeoutId;
      const cleanListeners = () => {
        clearTimeout(timeoutId);
        video.onloadedmetadata = null;
        video.onplaying = null;
        video.onerror = null;
      };

      const events = [];
      const onEvent = (type) => {
        events.push({
          type: type,
          currentTime: video.currentTime,
          duration: video.duration,
          videoWidth: video.videoWidth,
          videoHeight: video.videoHeight,
          readyState: video.readyState,
          networkState: video.networkState
        });
      };

      video.onloadedmetadata = () => onEvent('loadedmetadata');
      video.onplaying = () => {
        onEvent('playing');
        setTimeout(() => {
          cleanListeners();
          video.pause();
          window.__testResult = {
            success: true,
            events: events,
            videoWidth: video.videoWidth,
            videoHeight: video.videoHeight,
            duration: video.duration,
            readyState: video.readyState
          };
        }, 1500);
      };

      video.onerror = () => {
        const err = video.error;
        cleanListeners();
        window.__testResult = {
          success: false,
          errorCode: err ? err.code : 'UNKNOWN',
          errorMessage: err ? err.message : 'Unknown video error',
          events: events
        };
      };

      timeoutId = setTimeout(() => {
        cleanListeners();
        const hasStarted = video.currentTime > 0 || video.readyState >= 2;
        video.pause();
        window.__testResult = {
          success: hasStarted,
          timeout: true,
          events: events,
          videoWidth: video.videoWidth,
          videoHeight: video.videoHeight,
          duration: video.duration,
          readyState: video.readyState
        };
      }, 7000);

      // Trigger playback using webOS source element
      video.removeAttribute('src');
      video.innerHTML = '';
      const source = document.createElement('source');
      source.src = '${stream.url}';
      if ('${stream.mime}') {
        source.type = '${stream.mime}';
      }
      video.appendChild(source);
      video.load();
      video.play().catch(err => {
        events.push({ type: 'playRejected', message: String(err) });
      });
    })()`);

    // Poll window.__testResult until resolved or timeout
    let testResult = null;
    for (let t = 0; t < 10; t++) {
      await new Promise(r => setTimeout(r, 1000));
      testResult = await cdp.evaluate(`window.__testResult`);
      if (testResult) break;
    }

    if (!testResult) {
      testResult = { success: false, timeout: true, error: 'CDP poll timeout' };
    }

    console.log(`Result for ${stream.format}:`, JSON.stringify(testResult, null, 2));
    results.push({
      stream: stream.name,
      format: stream.format,
      mime: stream.mime,
      url: stream.url,
      result: testResult
    });

    if (testResult && testResult.success) {
      try {
        const scr = await cdp.send('Page.captureScreenshot', { format: 'png' });
        fs.writeFileSync(`AUDIT_REPORTS/MISSION_2/evidence/playback_${stream.format.toLowerCase()}.png`, Buffer.from(scr.data, 'base64'));
        console.log(`Saved screenshot for ${stream.format}`);
      } catch (e) {
        console.warn('Screenshot capture error:', e.message);
      }
    }
  }

  // Restore clean state
  await cdp.evaluate(`(() => {
    const video = document.getElementById('video-player') || document.querySelector('video');
    if (video) {
      video.pause();
      video.removeAttribute('src');
      video.innerHTML = '';
      video.load();
    }
    window.__testResult = null;
  })()`);

  fs.writeFileSync('AUDIT_REPORTS/MISSION_2/evidence/media_test_results.json', JSON.stringify(results, null, 2));
  cdp.close();
  console.log('\nMedia compatibility testing complete.');
}

runPlaybackTest().catch(console.error);
