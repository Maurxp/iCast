import os
import sys
import subprocess

TV_HOST = os.environ.get("TV_HOST", "")
TV_USER = os.environ.get("TV_USER", "root")
TV_PASS = os.environ.get("TV_PASS", "")
PLINK_PATH = r"C:\Program Files\PuTTY\plink.exe"
PSCP_PATH = r"C:\Program Files\PuTTY\pscp.exe"

def run_cmd(cmd_str, timeout=30):
    if not TV_HOST:
        return 1, "", "TV_HOST not set in environment\n"
    cmd = [PLINK_PATH, "-batch"]
    if TV_PASS:
        cmd.extend(["-pw", TV_PASS])
    cmd.extend([f"{TV_USER}@{TV_HOST}", cmd_str])
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout, proc.stderr

def scp_to(local_path, remote_path, timeout=60):
    if not TV_HOST:
        return 1, "", "TV_HOST not set in environment\n"
    cmd = [PSCP_PATH, "-batch"]
    if TV_PASS:
        cmd.extend(["-pw", TV_PASS])
    cmd.extend([local_path, f"{TV_USER}@{TV_HOST}:{remote_path}"])
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout, proc.stderr

def scp_from(remote_path, local_path, timeout=60):
    if not TV_HOST:
        return 1, "", "TV_HOST not set in environment\n"
    cmd = [PSCP_PATH, "-batch"]
    if TV_PASS:
        cmd.extend(["-pw", TV_PASS])
    cmd.extend([f"{TV_USER}@{TV_HOST}:{remote_path}", local_path])
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout, proc.stderr

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tv_exec.py \"<command>\"")
        sys.exit(1)
    
    command = " ".join(sys.argv[1:])
    code, stdout, stderr = run_cmd(command)
    if stdout:
        sys.stdout.write(stdout)
    if stderr:
        sys.stderr.write(stderr)
    sys.exit(code)
