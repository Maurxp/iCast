import { createCdpClient } from './tv_cdp.mjs';

async function main() {
  const cdp = await createCdpClient();
  const res = await cdp.evaluate(`({
    lastChannel: localStorage.getItem('iptv_last_channel'),
    lastKey: localStorage.getItem('iptv_last_channel_key'),
    playlists: localStorage.getItem('iptv_playlists'),
    bodySnippet: document.body.innerText.substring(0, 300)
  })`);

  console.log('Stored Values:\n', JSON.stringify(res, null, 2));
  cdp.close();
}

main().catch(console.error);

