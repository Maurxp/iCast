import { createCdpClient } from './tv_cdp.mjs';
import * as fs from 'fs';

async function main() {
  const cdp = await createCdpClient();
  console.log('Connected to CDP for D-pad navigation & channel tuning.');

  // 1. Inspect focus state before tuning
  const initialFocus = await cdp.evaluate(`(() => {
    const active = document.activeElement;
    const ringOwner = document.querySelector('[data-ring-owner]');
    const focusedCard = document.querySelector('.channel-card.focused, .focused, [data-focused]');
    return {
      activeTag: active ? active.tagName : null,
      activeClass: active ? active.className : null,
      ringOwnerId: ringOwner ? ringOwner.id : null,
      focusScope: ringOwner ? ringOwner.getAttribute('data-focus-scope') : null,
      focusedCardText: focusedCard ? focusedCard.textContent.trim() : null
    };
  })()`);

  console.log('Initial Focus State:', JSON.stringify(initialFocus, null, 2));

  // 2. Dispatch 'Enter' (keyCode 13, 'select') to tune the focused channel
  console.log('Dispatching SELECT (Enter) key event to tune channel 1...');
  await cdp.evaluate(`(() => {
    const evt = new KeyboardEvent('keydown', {
      bubbles: true,
      cancelable: true,
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13
    });
    window.dispatchEvent(evt);
  })()`);

  // Wait 3 seconds for channel tune and video element to load
  await new Promise(r => setTimeout(r, 3500));

  // 3. Inspect playback and active view
  const playbackState = await cdp.evaluate(`(() => {
    const video = document.getElementById('video-player') || document.querySelector('video');
    const playerView = document.getElementById('view-player');
    const channelsView = document.getElementById('view-channels');
    return {
      playerViewVisible: playerView ? playerView.style.display !== 'none' : false,
      channelsViewVisible: channelsView ? channelsView.style.display !== 'none' : false,
      videoSrc: video ? video.currentSrc || video.src : null,
      videoReadyState: video ? video.readyState : null,
      videoPaused: video ? video.paused : null,
      videoCurrentTime: video ? video.currentTime : null,
      videoDuration: video ? video.duration : null,
      videoWidth: video ? video.videoWidth : null,
      videoHeight: video ? video.videoHeight : null
    };
  })()`);

  console.log('Playback State after tuning:', JSON.stringify(playbackState, null, 2));

  // 4. Capture screenshot of playback view
  const scr = await cdp.send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync('AUDIT_REPORTS/MISSION_2/evidence/tv_channel_tuning_screenshot.png', Buffer.from(scr.data, 'base64'));
  console.log('Channel tuning screenshot saved!');

  cdp.close();
}

main().catch(console.error);

