#!/bin/sh
set -e

IPK="/tmp/iptv-audit-m2/com.lennylxx.iptv_1.17.0_all.ipk"

echo "=== STARTING CONTROLLED INSTALLATION ==="
echo "Target IPK: $IPK"
sha256sum "$IPK"

echo "=== CALLING LUNA APP INSTALL SERVICE ==="
luna-send -i -f luna://com.webos.appInstallService/dev/install "{\"id\":\"com.lennylxx.iptv\",\"ipkUrl\":\"$IPK\",\"subscribe\":true}" > /tmp/iptv-audit-m2/install_luna_log.txt 2>&1 &
PID=$!

# Wait for completion or timeout
echo "Installer started with PID $PID. Monitoring log..."
for i in $(seq 1 30); do
    sleep 1
    if grep -q "status" /tmp/iptv-audit-m2/install_luna_log.txt 2>/dev/null; then
        cat /tmp/iptv-audit-m2/install_luna_log.txt
        if grep -q "SUCCESS" /tmp/iptv-audit-m2/install_luna_log.txt || grep -q "FAILED" /tmp/iptv-audit-m2/install_luna_log.txt; then
            break
        fi
    fi
done

kill $PID 2>/dev/null || true
echo "=== INSTALL LOG CONTENT ==="
cat /tmp/iptv-audit-m2/install_luna_log.txt || true

echo "=== VERIFYING INSTALLED FILES ==="
echo "--- Application directory ---"
ls -la /media/developer/apps/usr/palm/applications/com.lennylxx.iptv/ 2>&1 || true
echo "--- Service directory ---"
ls -la /media/developer/apps/usr/palm/services/com.lennylxx.iptv.service/ 2>&1 || true

echo "=== CHECKING SAM / APP STATUS ==="
luna-send -n 1 luna://com.webos.applicationManager/getAppInfo '{"id":"com.lennylxx.iptv"}' 2>&1 || true

