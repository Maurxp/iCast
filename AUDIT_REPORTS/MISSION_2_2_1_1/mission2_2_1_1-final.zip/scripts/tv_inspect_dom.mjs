import { createCdpClient } from './tv_cdp.mjs';

async function main() {
  const cdp = await createCdpClient();
  const res = await cdp.evaluate(`({
    htmlClasses: document.documentElement.className,
    focusScope: document.querySelector('[data-focus-scope]') ? document.querySelector('[data-focus-scope]').getAttribute('data-focus-scope') : null,
    ringOwner: document.querySelector('[data-ring-owner]') ? document.querySelector('[data-ring-owner]').id : null,
    focusedElement: document.activeElement ? {
      tag: document.activeElement.tagName,
      id: document.activeElement.id,
      className: document.activeElement.className,
      text: document.activeElement.textContent ? document.activeElement.textContent.trim().substring(0, 40) : ''
    } : null,
    tabBarTabs: Array.from(document.querySelectorAll('.tab-bar-item, .tab')).map(t => ({
      key: t.getAttribute('data-key'),
      selected: t.classList.contains('selected') || t.classList.contains('active'),
      label: t.textContent.trim()
    })),
    localStorageKeys: Object.keys(localStorage),
    storageValues: {
      iptv_last_view: localStorage.getItem('iptv_last_view'),
      iptv_active_account: localStorage.getItem('iptv_active_account')
    }
  })`);

  console.log('DOM & Engine Quirks details:\n', JSON.stringify(res, null, 2));
  cdp.close();
}

main().catch(console.error);

