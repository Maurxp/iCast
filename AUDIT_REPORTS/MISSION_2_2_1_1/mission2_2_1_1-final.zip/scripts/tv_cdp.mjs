// CDP Client for webOS IPTV Player inspection

const TV_HOST = '192.168.1.8';
const CDP_PORT = 9998;

async function getPageTarget() {
  const res = await fetch(`http://${TV_HOST}:${CDP_PORT}/json`);
  const targets = await res.json();
  const page = targets.find(t => t.url && t.url.includes('com.lennylxx.iptv'));
  if (!page) {
    throw new Error('com.lennylxx.iptv page target not found: ' + JSON.stringify(targets));
  }
  return page;
}

export async function createCdpClient() {
  const target = await getPageTarget();
  const ws = new WebSocket(target.webSocketDebuggerUrl);

  let seq = 0;
  const pending = new Map();
  const listeners = [];

  await new Promise((resolve, reject) => {
    ws.onopen = resolve;
    ws.onerror = reject;
  });

  ws.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data);
      if (msg.id && pending.has(msg.id)) {
        const { resolve, reject } = pending.get(msg.id);
        pending.delete(msg.id);
        if (msg.error) reject(msg.error);
        else resolve(msg.result);
      } else {
        listeners.forEach(fn => fn(msg));
      }
    } catch (err) {
      console.error('Error parsing CDP message:', err);
    }
  };

  function send(method, params = {}) {
    const id = ++seq;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject });
      ws.send(JSON.stringify({ id, method, params }));
    });
  }

  return {
    send,
    onEvent: (fn) => listeners.push(fn),
    close: () => ws.close(),
    evaluate: async (expression, awaitPromise = true) => {
      const res = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise });
      if (res.exceptionDetails) {
        throw new Error(res.exceptionDetails.text || 'CDP evaluation exception');
      }
      return res.result ? res.result.value : undefined;
    }
  };
}

// Standalone execution: evaluate app state
if (process.argv[1] && process.argv[1].endsWith('tv_cdp.mjs')) {
  (async () => {
    try {
      const cdp = await createCdpClient();
      console.log('Connected to webOS IPTV Player CDP session.');

      await cdp.send('Runtime.enable');
      await cdp.send('Console.enable');

      const info = await cdp.evaluate(`({
        url: window.location.href,
        userAgent: navigator.userAgent,
        title: document.title,
        activeElement: document.activeElement ? document.activeElement.tagName : null,
        bodyClasses: document.body.className,
        hasApp: typeof window.app !== 'undefined',
        views: Array.from(document.querySelectorAll('.view')).map(v => ({ id: v.id, hidden: v.hidden, style: v.style.display }))
      })`);

      console.log('App state on TV:', JSON.stringify(info, null, 2));
      cdp.close();
    } catch (err) {
      console.error('CDP Error:', err);
      process.exit(1);
    }
  })();
}
