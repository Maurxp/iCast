import { createCdpClient } from './tv_cdp.mjs';

async function main() {
  const cdp = await createCdpClient();
  const res = await cdp.evaluate(`(() => {
    const video = document.querySelector('video') || document.createElement('video');
    const tests = [
      { format: 'HLS (m3u8)', type: 'application/vnd.apple.mpegurl' },
      { format: 'HLS (x-mpegurl)', type: 'application/x-mpegurl' },
      { format: 'MPEG-DASH', type: 'application/dash+xml' },
      { format: 'MPEG-TS', type: 'video/mp2t' },
      { format: 'MP4 (H.264+AAC)', type: 'video/mp4; codecs="avc1.42E01E, mp4a.40.2"' },
      { format: 'MP4 (H.265/HEVC)', type: 'video/mp4; codecs="hvc1.1.6.L93.B0"' },
      { format: 'WebM (VP9)', type: 'video/webm; codecs="vp9"' },
      { format: 'Audio MP3', type: 'audio/mpeg' },
      { format: 'Audio AAC', type: 'audio/aac' },
      { format: 'Audio AC-3 (Dolby Digital)', type: 'audio/mp4; codecs="ac-3"' },
      { format: 'Audio EC-3 (Dolby Digital Plus)', type: 'audio/mp4; codecs="ec-3"' }
    ];
    
    return {
      videoInDOM: Boolean(document.querySelector('video')),
      videoAttributes: document.querySelector('video') ? {
        id: document.querySelector('video').id,
        className: document.querySelector('video').className,
        src: document.querySelector('video').src
      } : null,
      canPlayTypeResults: tests.map(t => ({
        format: t.format,
        type: t.type,
        result: video.canPlayType(t.type)
      }))
    };
  })()`);

  console.log('Media Codec & Container Support on TV:\n', JSON.stringify(res, null, 2));
  cdp.close();
}

main().catch(console.error);

