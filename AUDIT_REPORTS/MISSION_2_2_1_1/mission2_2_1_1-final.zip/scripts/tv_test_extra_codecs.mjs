import { createCdpClient } from './tv_cdp.mjs';
import * as fs from 'fs';

const streams = [
  {
    name: 'MP4 Progressive (H.264 / AAC)',
    format: 'MP4',
    url: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    mime: 'video/mp4'
  },
  {
    name: 'MPEG-TS Stream (video/mp2t)',
    format: 'TS',
    url: 'https://test-streams.mux.dev/x36xhzz/url_0/url_460/00000.ts',
    mime: 'video/mp2t'
  }
];

async function main() {
  const cdp = await createCdpClient();
  const results = [];

  for (const stream of streams) {
    console.log(`\nTesting format: ${stream.name}...`);
    await cdp.evaluate(`window.__testResult = null;`);

    await cdp.evaluate(`(() => {
      const video = document.getElementById('video-player') || document.querySelector('video');
      let timeoutId;
      const cleanListeners = () => {
        clearTimeout(timeoutId);
        video.onloadedmetadata = null;
        video.onplaying = null;
        video.onerror = null;
      };

      const events = [];
      const onEvent = (type) => {
        events.push({
          type: type,
          currentTime: video.currentTime,
          duration: video.duration,
          videoWidth: video.videoWidth,
          videoHeight: video.videoHeight,
          readyState: video.readyState,
          networkState: video.networkState
        });
      };

      video.onloadedmetadata = () => onEvent('loadedmetadata');
      video.onplaying = () => {
        onEvent('playing');
        setTimeout(() => {
          cleanListeners();
          video.pause();
          window.__testResult = {
            success: true,
            events: events,
            videoWidth: video.videoWidth,
            videoHeight: video.videoHeight,
            duration: video.duration,
            readyState: video.readyState
          };
        }, 1500);
      };

      video.onerror = () => {
        const err = video.error;
        cleanListeners();
        window.__testResult = {
          success: false,
          errorCode: err ? err.code : 'UNKNOWN',
          errorMessage: err ? err.message : 'Unknown video error',
          events: events
        };
      };

      timeoutId = setTimeout(() => {
        cleanListeners();
        const hasStarted = video.currentTime > 0 || video.readyState >= 2;
        video.pause();
        window.__testResult = {
          success: hasStarted,
          timeout: true,
          events: events,
          videoWidth: video.videoWidth,
          videoHeight: video.videoHeight,
          duration: video.duration,
          readyState: video.readyState
        };
      }, 12000);

      video.removeAttribute('src');
      video.innerHTML = '';
      const source = document.createElement('source');
      source.src = '${stream.url}';
      if ('${stream.mime}') {
        source.type = '${stream.mime}';
      }
      video.appendChild(source);
      video.load();
      video.play().catch(err => {
        events.push({ type: 'playRejected', message: String(err) });
      });
    })()`);

    let testResult = null;
    for (let t = 0; t < 15; t++) {
      await new Promise(r => setTimeout(r, 1000));
      testResult = await cdp.evaluate(`window.__testResult`);
      if (testResult) break;
    }

    console.log(`Result for ${stream.format}:`, JSON.stringify(testResult, null, 2));
    results.push({ stream: stream.name, format: stream.format, result: testResult });

    if (testResult && testResult.success) {
      try {
        const scr = await cdp.send('Page.captureScreenshot', { format: 'png' });
        fs.writeFileSync(`AUDIT_REPORTS/MISSION_2/evidence/playback_${stream.format.toLowerCase()}.png`, Buffer.from(scr.data, 'base64'));
        console.log(`Saved screenshot for ${stream.format}`);
      } catch (e) {}
    }
  }

  // Restore clean state
  await cdp.evaluate(`(() => {
    const video = document.getElementById('video-player') || document.querySelector('video');
    if (video) {
      video.pause();
      video.removeAttribute('src');
      video.innerHTML = '';
      video.load();
    }
    window.__testResult = null;
  })()`);

  cdp.close();
}

main().catch(console.error);

