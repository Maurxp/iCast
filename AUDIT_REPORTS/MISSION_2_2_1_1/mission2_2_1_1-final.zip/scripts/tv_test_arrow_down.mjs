import { createCdpClient } from './tv_cdp.mjs';
import * as fs from 'fs';

async function main() {
  const cdp = await createCdpClient();
  console.log('Dispatching ArrowDown to move to Channel 2...');
  
  await cdp.evaluate(`(() => {
    window.dispatchEvent(new KeyboardEvent('keydown', {
      bubbles: true,
      cancelable: true,
      key: 'ArrowDown',
      code: 'ArrowDown',
      keyCode: 40,
      which: 40
    }));
  })()`);

  await new Promise(r => setTimeout(r, 2000));

  const state = await cdp.evaluate(`(() => {
    const focused = document.querySelector('.focused, [data-focused], [data-key]');
    const ringOwner = document.querySelector('[data-ring-owner]');
    return {
      focusedTag: focused ? focused.tagName : null,
      focusedText: focused ? focused.textContent.trim().substring(0, 50) : null,
      ringOwner: ringOwner ? ringOwner.id : null,
      focusScope: ringOwner ? ringOwner.getAttribute('data-focus-scope') : null
    };
  })()`);

  console.log('State after ArrowDown:', JSON.stringify(state, null, 2));

  const scr = await cdp.send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync('AUDIT_REPORTS/MISSION_2/evidence/tv_channel_nav_arrowdown.png', Buffer.from(scr.data, 'base64'));
  console.log('ArrowDown screenshot saved.');

  cdp.close();
}

main().catch(console.error);

