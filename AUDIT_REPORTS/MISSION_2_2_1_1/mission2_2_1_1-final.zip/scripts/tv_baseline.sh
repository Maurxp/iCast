#!/bin/sh
set -e

echo "=== SECTION 1: KERNEL & OS VERSION ==="
uname -a
echo "--- /etc/starfish-release ---"
cat /etc/starfish-release 2>/dev/null || true
echo "--- /etc/issue ---"
cat /etc/issue 2>/dev/null || true
echo "--- /etc/version ---"
cat /etc/version 2>/dev/null || true

echo "=== SECTION 2: HARDWARE & CPU INFO ==="
cat /proc/cpuinfo

echo "=== SECTION 3: UPTIME & LOAD ==="
uptime

echo "=== SECTION 4: MEMORY INFO ==="
cat /proc/meminfo

echo "=== SECTION 5: DISK & MOUNTS ==="
df -h
echo "--- Mount points ---"
cat /proc/mounts

echo "=== SECTION 6: RUNNING PROCESSES (SUMMARY & DETAIL) ==="
ps aux

echo "=== SECTION 7: NETWORK & OPEN PORTS ==="
ifconfig
echo "--- Listening ports ---"
netstat -tuln 2>/dev/null || true

echo "=== SECTION 8: LUNA SYSTEM PROPERTIES ==="
luna-send -n 1 luna://com.webos.service.tv.systemproperty/getSystemInfo '{"keys":["modelName","firmwareVersion","sdkVersion","boardType","chipType","programId"]}' 2>&1 || true

echo "=== SECTION 9: INSTALLED APPLICATIONS & SERVICES ==="
echo "--- Developer Applications ---"
ls -la /media/developer/apps/usr/palm/applications/ 2>&1 || true
echo "--- Developer Services ---"
ls -la /media/developer/apps/usr/palm/services/ 2>&1 || true
echo "--- Check com.lennylxx.iptv presence ---"
ls -la /media/developer/apps/usr/palm/applications/com.lennylxx.iptv 2>&1 || true
ls -la /media/developer/apps/usr/palm/services/com.lennylxx.iptv.service 2>&1 || true

echo "=== SECTION 10: WEBOS PACKAGE / APP INSTALL SERVICES ==="
which opkg luna-send ares-install node npm 2>&1 || true
node -v 2>&1 || true

echo "=== BASELINE COLLECTION COMPLETE ==="

